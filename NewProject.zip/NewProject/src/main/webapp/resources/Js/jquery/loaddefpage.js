  function def(x){
   	document.location.href =x; 
   	
  }
  
  function defaultPage(){
	  $.ajax({
  		url: 'getDefPageName.action',
  		dataType: "json",
  		success: (function(result) {
  			def(result.DefPage);
  	    })
    });
	   
  };

