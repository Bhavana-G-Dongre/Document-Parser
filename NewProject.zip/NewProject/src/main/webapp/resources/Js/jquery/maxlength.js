/*
  name      : ClassBehaviours, the javascript framework based on class-name parsing
  update      : 9.2.2
  author      : Maurice van Creij
  dependencies  : jquery.classbehaviours.js
  info      : http://www.classbehaviours.com/

    This file is part of jQuery.classBehaviours.
    
    ClassBehaviours is a javascript framework based on class-name parsing.
    Copyright (C) 2008  Maurice van Creij

    ClassBehaviours is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    ClassBehaviours is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ClassBehaviours. If not, see http://www.gnu.org/licenses/gpl.html.
*/

  // create the jQuery object if it doesn't already exist
  if(typeof(jQuery)=='undefined') jQuery = function(){};
  
  // create the root classbehaviours object if it doesn't already exist
  if(typeof(jQuery.classBehaviours)=='undefined') jQuery.classBehaviours = function(){};
  
  // create the handlers child object if it doesn't already exist
  if(typeof(jQuery.classBehaviours.handlers)=='undefined') jQuery.classBehaviours.handlers = function(){}

  // Filter the contents of a table based on a keyword
  jQuery.classBehaviours.handlers.maxLength = {
    // properties
    name: 'maxLength',
    // methods
    start: function(node){
      // set the event handlers of this element
      node.onkeydown = this.restrict;
      node.onkeyup = this.restrict;
      node.onchange = this.restrict;
      // initial value
      this.restrict(node);
    },
    // events
    restrict: function(that){
      var objNode = (typeof(this.nodeName)=='undefined') ? that : this ;
      // get the limit value
      lengthLimit = parseInt(jQuery.classBehaviours.utilities.getClassParameter(objNode, 'max', '140'));
      // get the output indicator
      outputIndicator = jQuery.classBehaviours.utilities.getClassParameter(objNode, 'id', null);
      // refuse new input if the limit is reached
      keyPress = (typeof(event)!='undefined')? event.keyCode : that.which ;
      if(objNode.value.length==lengthLimit+1 && keyPress!=8 && keyPress!=46) return false;
      // measure the length of the content
      if(objNode.value.length>lengthLimit) objNode.value = objNode.value.substring(0, lengthLimit);
      // update the indicator
      if(outputIndicator!=null) document.getElementById(outputIndicator).innerHTML = lengthLimit - objNode.value.length;
    }
  }
      
  // add this addon to the jQuery object
  if(typeof(jQuery.fn)!='undefined'){
    // extend jQuery with this method
    jQuery.fn.maxLength = function(){
      return this.each(
        function(){
          jQuery.classBehaviours.handlers.maxLength.start(this);
        }
      );
    };
    // set the event handler for this jQuery method
    $(document).ready(
      function(){
        $(".maxLength").maxLength();
      }
    );
  }
