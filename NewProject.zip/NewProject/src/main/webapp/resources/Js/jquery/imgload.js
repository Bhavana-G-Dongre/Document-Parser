/*

Developer: Aishwar Muthuraman
Web: http://www.ai-projects.info
Create Date: Dec 31, 2008
Update Date: April 21, 2009

Version 1.0.1
=============
Version 1.0 released was found to be an incomplete release.
It would not have worked (It was different from the version
running on http://www.ai-projects.info). Sorry about that.

Here are some updates on this version (from the correct V.1.0).
 - Using addEventListener to add events so that this does
 not kill all other mousedown and keypress events on the 
 document
 - Added a check to see if onblur is set on the link element;
 this would improve hit rate - no/low false positives

Description:
===========
Script that would produce a lightbox type effect without
the html code changes needed to be implemented in blogger
posts to accomodate it

*/

if (document.addEventListener) {
	document.addEventListener("mousedown", showImage, false);
	document.addEventListener("keypress", showImage, true);
} else {
	document.attachEvent("onmousedown",showImage)
	document.attachEvent("onkeypress",showImage)
}
//document.onmousedown = showImage;
//document.onkeypress = showImage;
var bgUrl = "http://i41.tinypic.com/2nluy51.png";
var preLoaderGif = "http://i39.tinypic.com/29c2i9w.gif";

function showImage(e) {
   //alert('showImage called');
   if (!e) e = window.event;
   var check = document.getElementById('imageHighlighted');
   var body = document.getElementsByTagName('body')[0];
   if (!check) {
    if ((e.type == "mousedown") | ((e.type == "keydown") && (e.keyCode == 13))) {
      if (e.target) var element = e.target;
	  if (e.srcElement) var element = event.srcElement;
	  var parent = element.parentNode;
	  if (element.nodeName == "A") {
	   // Switch parent, child names
	   parent = element;
	   element = parent.childNodes[0];
	  }

	  if (element.nodeName == "IMG" && parent.nodeName == "A" && (parent.onblur != null || parent.getAttribute('imageanchor') !=null)) {
	
	    // Work on the big container div
	    var newDiv = document.createElement('div');
		var divId = 'imageHighlighted';
		newDiv.setAttribute('id',divId);
		newDiv.style.position = "fixed";
		newDiv.style.top = "0px";
		newDiv.style.left = "0px";
		newDiv.style.width = "100%";
		newDiv.style.height = "100%";
		newDiv.style.zIndex = "50";
		newDiv.style.textAlign = "left";
		newDiv.style.background = "url('"+bgUrl+"')";
		body.appendChild(newDiv);
		
		// Work on the pre-loader
		var preLoaderDiv = document.createElement('div');
		preLoaderDiv.style.height = "100%";
		preLoaderDiv.style.width = "100%";
		preLoaderDiv.style.background = "url('"+preLoaderGif+"') center center no-repeat";
		newDiv.appendChild(preLoaderDiv);
		
		//  Do not proceed with the "link-clicking" event
	    parent.onclick = function () { return false; }
		
		// Put the image in the center of the div and removing the preloading image
		var newimg = new Image();
		newimg.onload = function () {
		 preLoaderDiv.style.background = "";
		//var newimg_w = document.body.clientWidth;
		// var newimg_h = document.body.clientHeight;
		var newimg_w = newimg.width;
		var newimg_h = newimg.height;

		 if (window.innerHeight) {
		 	var screen_w = window.innerWidth;
		 	var screen_h = window.innerHeight;
		 }
		 else 
		 if (document.documentElement) {
		 	var screen_w = document.documentElement.clientWidth;
		 	var screen_h = document.documentElement.clientHeight;
		 } else {
		 	var screen_w = document.body.clientWidth;
		 	var screen_h = document.body.clientHeight;
		 }
		 var top = (screen_h - newimg_h)/2;
		 var left = (screen_w - newimg_w)/2;
		 if (newimg_w > screen_w) {
		  left = 0;
		  screen_w = newimg_w;
		 }
		 if (newimg_h > screen_h) {
		  top = 0;
		  screen_h = newimg_h;
		   //newimg_h = screen_h;
		 }
		 newimg.style.position = "relative";
		 newimg.style.top = top+"px";
		 newimg.style.left = left+"px";
		//alert(screen_h);
		if (left != 0) newDiv.style.width = "100%"; else newDiv.style.width = screen_w+"px";
		if (top != 0) newDiv.style.height = "100%"; else newDiv.style.height = screen_h+"px";
		//if (left != 0) newDiv.style.width = "100%"; else newDiv.style.width = "50%";
		// if (top != 0) newDiv.style.height = "100%"; else newDiv.style.height = "50%";
		
		if (newimg_w >  1000) newimg.setAttribute("width", "1000px");
		if (newimg_h >  600) newimg.setAttribute("height", "700px"); 
		 preLoaderDiv.appendChild(newimg);
		 return false;
	    } 
		
		// Load the image
		if (parent.href.search(/blogspot\.com/) > 0)
			newimg.src = encodeURI(parent.href.replace(/\-h/, ''));
		else 
			newimg.src = encodeURI(parent.href);
	  }
	 }
   } else {
      body.removeChild(check);
   }
}
