/*
 * Common functions used in FMS  
 */


function callSmallGridWidth(){
	
	var finalSmallWidth= null;
	if(navigator.appName == "Microsoft Internet Explorer"){
		var smallWidth = document.documentElement.offsetWidth;
		finalSmallWidth = smallWidth*70/100;
	} else {
		var smallWidth = window.innerWidth;
		finalSmallWidth = smallWidth*70/100;
	}
	
	return finalSmallWidth;
}

function returnHeight(){
	
	var finalHeight = null;
	if(navigator.appName == "Microsoft Internet Explorer"){
		var height = document.documentElement.offsetHeight;
		finalHeight = height-135;
	}else {
		var height = window.innerHeight;
		finalHeight = height-159;
	}
	
	return finalHeight;
}