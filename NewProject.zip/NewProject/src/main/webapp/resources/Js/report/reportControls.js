   var totPage = 0;

   function callAjaxFunctionLoad(strURL,calledFrom){
	   var xmlHttp;
	   if (window.XMLHttpRequest){ // Mozilla, Safari, ...
	     var xmlHttp = new XMLHttpRequest();
	   }else if (window.ActiveXObject){ // IE
	     var xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	   }
	   xmlHttp.open('POST', strURL, true);
	   xmlHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	   xmlHttp.send(strURL);
	   xmlHttp.onreadystatechange = function() {
	   if (xmlHttp.readyState == 4) {
	     if(calledFrom == "totalPageCount"){
	        featchTotalPage(xmlHttp.responseText);	        
	      } else if(calledFrom =="rptPrint"){
	       	printReport(xmlHttp.responseText);
	       }
	     }
	   }
	 }
   
    function  featchTotalPage(data){
     var JSONObject=null;
     JSONObject=jQuery.parseJSON(data);      
     totPage = JSONObject.TotalPage;
     if(totPage>0){
    	 $('#pages').val('1');
     }else{
    	 $('#pages').val('0');
     }     
     $("#totPage").html(" / "+totPage);
   }
   
   function first(){
	  if(parseInt($('#pages').val())==1) return;
	  $('#pages').val('1');	
	  viewRpt();
   }
   function last(){
	 if(parseInt($('#pages').val())==totPage) return;
	 $('#pages').val(totPage);
	 viewRpt();
   }

   function next(){
	   if(parseInt($('#pages').val())==totPage) return;
	   $('#pages').val(parseInt($('#pages').val()) +1);
	   viewRpt();
   }

   function previous(){
	   if(parseInt($('#pages').val())==1) return;
	  $('#pages').val(parseInt($('#pages').val())-1);
	  viewRpt();
   }

   function viewRpt(){
	   $("#Report").css("text-align", "center");
	   $("#Report").html("<img align=\"middle\"  src=\"/PMSLatest/images/reports/loading.gif\">");
	   $.ajax({
			url: contxtPath+"/rptViewChange.action?zoomRatio="+$('#zoomRatio').val()+"&curPage="+$('#pages').val(),
	 	    success: function( data ) {
	 	    	$("#Report").css("text-align", "left");
	 	    	$("#Report").html(data);	 	    	
			}
		});
   }
   
   function rptPrint(){
       callAjaxFunctionLoad(contxtPath+"/rptPrint.action","rptPrint");
   }
   
   
   function hideInputPart() {
		if ($('#inputArea').is(':hidden')) {
			$("#inputArea").show();
			$("#Report").height($("#Report").height()-$("#inputArea").height());
			$("#hideOrExpand").attr('src', contxtPath+'/images/firstgrid1.png');
		} else {
			$("#Report").height($("#Report").height()+$("#inputArea").height());
			$("#inputArea").hide();
			$("#hideOrExpand").attr('src', contxtPath+'/images/nextgrid1.png');
		}
	}
