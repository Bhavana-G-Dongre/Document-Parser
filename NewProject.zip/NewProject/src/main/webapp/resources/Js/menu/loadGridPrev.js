
 function loadMyGridPrevList(gridId,myGirdPrevList){
	 var myList = myGirdPrevList.split(",");
	 var myId;
	 //alert(myGirdPrevList);
	 for(var i=0;i<myList.length-1;i++){
		 myId = '#'+myList[i]+'_'+gridId;
		 $(myId).removeClass('ui-state-disabled');
	 }
 }


