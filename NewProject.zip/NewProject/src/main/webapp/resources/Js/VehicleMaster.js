var flag=0;
function isDateValid(toCheckDate)
 {
	 	var Date_array=toCheckDate.split('/');
	    var d=Date_array[0];
		var m=Date_array[1];
		var y=Date_array[2];
		var months = [31,28,31,30,31,30,31,31,30,31,30,31];
		if(!(d>0 && m>0 && y>0 && m<=12 && (d<=months[m-1] || (m==2 && d==29 && ((y%4==0&& y%100!=0) || (y%400==0)))) )){
			return false;
		}  
		else {
			return true;
		}
 }

function forward(){ 	 

	 if($("#vehicleNo").val().length==0){
   		   alert("Please enter the  Vechicle No.");
   		   $("#vehicleNo").focus();
   		   return false;
   		}   	
   	if($("#vehicleType option:selected").val()=="-1"){
		 alert("Please select Vehicle Type.");
		 $("#vehicleType").focus();
		 return false;
	 }	 
   	    
   	
   	if($("#unitId option:selected").val()=="-1"){
		 alert("Please select Unit Code.");
		 $("#unitId").focus();
		 return false;
	 }	 
   	
  
   	if($("#fuelType option:selected").val()=="-1"){
		 alert("Please select the Fuel Type .");
		 $("#fuelType").focus();
		 return false;
	 }	 
	
	  if($("#repairsCumulative").val().length==0){
	  		   alert("Please enter the  Repairs Cumulative");
	  		   $("#repairsCumulative").focus();
	  		   return false;
	  	 } 
	  
	  if($("#repairsYear").val().length==0){
		   alert("Please enter the Repairs Year");
		   $("#repairsYear").focus();
		   return false;
		}
	  
	  if($("#vehicleCost").val().length==0){
		   alert("Please enter the Vehicle Cost ");
		   $("#vehicleCost").focus();
		   return false;
		}
	  
	  if($('input:radio[name=lifeTime]:checked').val()=='F'){
	  	  var dat1= $("#taxPaidUpto1").val();
		   if(!isDateValid(dat1)){
			  alert("Enter Valid Date");
			  $("#taxPaidUpto1").focus();
			  return false;
		  }
	  }
	 	  
	  if(flag==1){ //In Update Mode
		   
		 if($('#taxpayDate1').val().length!=1)
		  {
		  var dat2= $("#taxpayDate1").val();
		   if(!isDateValid(dat2)){
			  alert("Enter Valid Date");
			  $("#taxpayDate1").focus();
			  return false;
		  }
		  
		  }
		 $.post('editVehicle.action?id='+$("#rowIdVal").val()+'&vehicleNo='+$("#vehicleNo").val()+'&vehicleType='+$("#vehicleType option:selected").val()+'&unitId1='+$("#unitId option:selected").val()+'&fuelType='+$("#fuelType option:selected").val()+'&taxPaid='+$('input:radio[name=taxPaid]:checked').val()+'&taxpayDate1='+$("#taxpayDate1").val()+'&lifeTime='+$('input:radio[name=lifeTime]:checked').val()+'&taxPaidUpto1='+$("#taxPaidUpto1").val()+'&repairsCumulative='+$("#repairsCumulative").val()+'&repairsYear='+$("#repairsYear").val()+'&vehicleCost='+$("#vehicleCost").val());
		  location.reload();
		  document.getElementById('submitForm').reset();
		  flag = 0;		 
		 return false;
	  }
	  if($('#taxpayDate1').val().length!=0)
	  {
	  var dat2= $("#taxpayDate1").val();
	   if(!isDateValid(dat2)){
		  alert("Enter Valid Date");
		  $("#taxpayDate1").focus();
		  return false;
	  }
	  
	  }
	  
	  return true;
  }
   function checkTaxPaidUp(){
   
   		if($('input:radio[name=lifeTime]:checked').val()=='T'){
   			     $("#taxPaidUpto1").hide();
   			     $("#taxPaidLabel").hide();
   			     $("#taxPaidUpto1").val(" ");
		     }
   		if($('input:radio[name=lifeTime]:checked').val()=='F'){
   			$("#taxPaidUpto1").show();
   			$("#taxPaidLabel").show();
   			$("#taxPaidUpto1").focus();
			}
    }  
  
   
$(document).ready(function() {
	$("#repairsYear").numbers();
	$("#vehicleCost").decimal();
	$("#vehicleNo").numberLettersAndSpaceAndBackspace();
	$("#repairsCumulative").numbers();
	
	
	
	$('#taxpayDate1').datepicker({
	   	 dateFormat: 'dd/mm/yy',
	   	 changeYear : true,
   	     changeMonth : true
   });
	$('#taxPaidUpto1').datepicker({
	    dateFormat: 'dd/mm/yy',
	   	changeYear : true,
  	    changeMonth : true
  });
	$('#repairsYear').datepicker({
	    dateFormat: 'yy',
	   	changeYear : true
  });
	
	 var delSettings ={
			  // define settings for Delete 
			  mtype: "post",	  
			  onclickSubmit: function (rp_ge, rowid) {		         
			             rp_ge.url = "deleteVehicle.action?vehicleId="+rowid;
			             $("#vehicleMasterlist").trigger("reloadGrid");
			  }
		  };		
	 
	   $("#vehicleMasterlist").jqGrid({
	    	datatype:'xml',
	 	  	mtype: 'Post', 		
			url:"vechMasterView.action?action=fetchData",	  	   
			colNames:['Vehicle No','Vehicle Type','Unit Code','Unit Code','Fuel Type','Tax Paid','Tax Pay Date','Life Time','Tax Paid Upto','Repairs Cumulative','Repairs Year','Vehicle Cost'],
			colModel:[
	          	{ name: 'vehicleNo', index: 'vehicleNo',width : 108, align:'left',editable:true} ,
	   			{ name: 'vehicleType',index: 'vehicleType',width : 100,editable:true},
	    		{ name: 'unitId', index: 'unitId',width :-1 ,align: 'left',editable:true ,edittype:'select', editoptions:{dataUrl:'getUnitcodes.action'}},
	    		{ name: 'UnitCode', index: 'UnitCode',width : 100 ,align: 'left',editable:false} ,
	    		{ name: 'fuelType',index: 'fuelType',width :95,editable:true},
	    		{ name: 'taxPaid', index: 'taxPaid',width : 85,align: 'left',editable:true} ,
	    		{ name: 'taxpayDate1',index: 'taxpayDate1',width : 117,formatter:'date',editable:true},
	    		{ name: 'lifeTime', index: 'lifeTime',width :87 ,align: 'left',editable:true} ,
	    		{ name: 'taxPaidUpto1', index: 'taxPaidUpto1',width : 122 ,formatter:'date',align: 'left',editable:true},
	    		{ name: 'repairsCumulative', index: 'repairsCumulative',width : 100 ,align: 'left',editable:true},
	    		{ name: 'repairsYear', index: 'repairsYear',width :112 ,align: 'left',editable:true },
	    		{ name: 'vehicleCost', index: 'vehicleCost',width : 110 ,align: 'left',editable:true},		
	 		 ],
	 	   rowNum:10,
		   loadonce:true,
		   rownumbers:true,
	 	   rowList:[5,10,20],
		   cellEdit: false, 
		   viewrecords:true,
		   caption:'Vehicle Master Detail',		   
		   pager: '#pager',
		   width: 795,
		   height: 'auto',
		   shrinkToFit:false,
		   closeAfterAdd:true,
	       closeAfterEdit:true,
	       reloadAfterSubmit:true,
		    cellsubmit: 'clientArray' 
		 });
	 	
	 	jQuery("#vehicleMasterlist").navGrid('#pager',{ edit:false,add:false,del:true,search:true },{},{},delSettings,{})
	 	.navButtonAdd('#pager',{ caption:"Edit", buttonicon:"ui-icon-pencil",position:"first",title:'Edit',
		 	onClickButton:function(){	
		 		flag=1;
		 		var rowid = $("#vehicleMasterlist").jqGrid('getGridParam', 'selrow');	        	
	        	if(rowid==null){
	        		alert("Please select Row.");
	        		return;
		        }
	        	var gridRow = $("#vehicleMasterlist").getRowData(rowid);
	        	$("#rowIdVal").val(rowid);
	        	$("#vehicleNo").val(gridRow.vehicleNo);
	    		$("#vehicleType").val(gridRow.vehicleType);
	    		$("#unitId").val(gridRow.unitId);
	    		$("#fuelType").val(gridRow.fuelType);
	    		var taxpaidValue = gridRow.taxPaid;
	    		$("[name=taxPaid]").filter("[value="+taxpaidValue+"]").attr("checked","checked"); 	
	    		$("#taxpayDate1").val(gridRow.taxpayDate1);
	    		$("#lifeTime").val(gridRow.lifeTime);
	    		var lifeTimeValue = gridRow.lifeTime;
	    	   if(lifeTimeValue=="T")
	    		   {
	    		   $("#taxPaidUpto1").hide();
	    		   $("#taxPaidLabel").hide();
	    		   }
	    	   else{
	    		   $("#taxPaidUpto1").show();
	    		   $("#taxPaidLabel").show();	    		   
	    	       }
	    		$("[name=lifeTime]").filter("[value="+lifeTimeValue+"]").attr("checked","checked"); 		
	    		$("#taxPaidUpto1").val(gridRow.taxPaidUpto1);
	    		$("#repairsCumulative").val(gridRow.repairsCumulative);
	    		$("#repairsYear").val(gridRow.repairsYear);
	    		$("#vehicleCost").val(gridRow.vehicleCost);
	    		
		 	}
		});
	});
     