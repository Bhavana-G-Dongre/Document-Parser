// Safely use $
(function($) {

  $.fn._ie_select=function() { 
  
    return $(this).each(function() { 
    
      var a = $(this),
          p = a.parent();
    
    
      p.css('position','relative');
     
      var o = a.position(),
          h = a.outerHeight(),
          l = o.left,
          t = o.top;
    
      var c = a.clone(true);
    
      $.data(c,'element',a);
    
      c.css({
        zIndex   : 100,
        height   : h,
        top      : t,
        left     : l,
        position : 'absolute',
        width    : 'auto',
        opacity  : 0
      }).attr({
        id    : this.id + '-clone',
        name  : this.name + '-clone'
      }).change(function() {
        $.data(c,'element')
          .val($(this).val())
          .trigger('change');
      });
        
      a.before(c).click(function() { 
        c.trigger('click');
      });
    
    }); // END RETURN
  
  }; // END PLUGIN

})(jQuery); // END SAFETY