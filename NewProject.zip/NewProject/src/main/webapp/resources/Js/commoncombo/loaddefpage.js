  function def(x){
   	document.location.href =x; 
   	
  }
  function defaultPage(){
	  //alert("de");
	  $.ajax({
  		url: 'getDefPageName.action',
  		dataType: "json",
  		success: (function(result) {
  			
  			//alert(result);
  			def(result.DefPage);
  	    })
    });
	   
  };


