


function LoadAllocationWiseAmountDetailsGrid()
{
	var code=$("#UccCode").val();
	var billNo = $("#BillNumber").val();
	var grid="#"+"AllocationWiseAmountDetailsList";
	$(grid).jqGrid({
		/*url:'LoadAllocationWiseAmountDetails.action?strCode='+code+'&intBillNo='+billNo,*/
		datatype:'local',
	    mtype: 'Post',
		colNames: ['Allocation','Amount'],
		colModel: [
             { name: 'Allocation', index: 'Allocation',width: 350, align: 'center'},
             { name: 'Amount', index: 'Amount',width: 350, align: 'right', template: numberTemplate}
           ],
           rownumbers: true,
           pagination: true,
           pager: '#AllocationWiseAmountDetailsPager',
           rowNum:30,
           rowlist:[10, 20],
           viewrecords:true,
           shrinkToFit:false,
           width: 500,
           height: 'auto',
           loadonce: false,
           caption:'Allocation details Of Bill ',
           gridComplete: function(data)
           {
        	   /*alert("dd");
        	   $(grid+">*").css({"width":""});*/
           }
     });
$(grid).setGridParam({ 
	url:'LoadAllocationWiseAmountDetails.action?strCode='+code+'&intBillNo='+billNo,
		 loadonce:false
		}).trigger("reloadGrid");
//	$(grid).setGridParam({ 
//		url:'LoadAllocationWiseAmountDetails.action?strCode='+code+'&intBillNo='+billNo,
//		
//			 loadonce:false
//			}).trigger("reloadGrid");
	
}

function WriteOnField(json)
{
	/*alert("object o json "+ json);*/
	if(json == null)
	{
		messageBox("Improper data found for this bill");	
		resettem();
	}
	if(json.FoundMessage=="Found")
	{
		if(json.BillNo > 1)
		{
			/*$('#AccountFileRef').attr("disabled",true);*/
		}
		var expTot = parseFloat(""+json.EXPNOW)+parseFloat(""+json.CURR_W_VAL);
		$("#expenditureTot").val(expTot.toFixed(2)); 
		$("#budgetGrant").val(parseFloat(""+json.BGRANT).toFixed(2));
		
		if(json.STATUS == '6' && expTot > parseFloat(""+json.BGRANT))
		{
			messageBox("The Expenditure exceeds Budget granted for the current financial year and project");
			$("#oItemPan").hide();
		}	
		 $("#CO6Date").val(json.Co6Date); 
		 $("#VC").val(json.VC);
		 $("#UccCode").val(json.UccCode); 
		 $("#BillNumber").val(json.BillNo);
		 $("#BillType").val(json.billType); 
		 $("#AgreementNo").val(json.AgreementNo);
		 $("#PrevBillNumber").val(json.PrevBillNo);
		 $("#PrevBillDate").val(json.PrevBillDate);
		 $("#AgreementDate").val(json.AGREEMENT_DATE);
		 $("#ProjectCode").val(json.PROJ_CODE);
		 $("#ProjectName").val(json.PROJ_NAME);
		 $("#VoucherNo").val(json.VOC_NO);
		 $("#VoucherDate").val(json.VOC_DT);
		 $("#BankCode").val(json.BankCode);
		 $("#ContractorCode").val(json.CONTRACTOR_CODE);
		 $("#ContractorName").val(json.CONTRACTOR_NAME);
		 $("#CurrentBillValue").val(parseFloat(""+json.CURR_W_VAL).toFixed(2));
		 $("#MeasuredBy").val(json.MEAS_BY_CODE+"-"+json.MEAS_BY_DESCRIPTION);
		 $("#MeasuredOnDate").val(json.MEA_FRM_DT);
		 $("#TestCheckedBy").val(json.TST_CODE+"-"+json.TST_DESCRIPTION);
		 $("#TestCheckedOnDate").val(json.TST_CHK_DT);
		 $("#CertifiedBy").val(json.CERT_BY_CODE+"-"+json.CERT_BY_DESCRIPTION);
		 $("#CumulativeAmt").val(parseFloat(""+json.CUM_W_VAL).toFixed(2));
		 $("#CumulativeBillAmt").val(parseFloat(""+json.CumulativeBillAmt).toFixed(2));
		 $("#MBNumber").val(json.MB_NO);
		 $("#MBPageNumber").val(json.MB_PG_NO);
		 $("#BillDate").val(json.BILL_DT);
		 $("#AgreementCurrency").val(json.AGREEMENT_CURR);
		  $("#TotalforAgreement").val(json.AGREEMENT_VALUE);
		  $("#amtPayable").val(parseFloat(""+json.AMT_PYABLE).toFixed(2));
		  $("#NetPayable").val(parseFloat(""+json.NET_PYABLE).toFixed(2));
		  $("#Payable").val(parseFloat(""+json.NET_PYABLE).toFixed(2));
		  $("#TotalRecoveries").val(parseFloat(""+json.RECOVERY).toFixed(2));
		  $("#RlyRecoveries").val(parseFloat(""+json.RLYRECV).toFixed(2));
		  $("#TotalNRB").val(parseFloat(""+json.NRB).toFixed(2));
		  $("#IFSCCode").val(json.IFSCCODE);
		  $("#AccountNo").val(json.ACCOUNTNO);
		   $("#CertificationCode").val(json.CERT_CD+" - "+json.SDESC);
		   $("select#Division option").remove();
		   $("select#SubDivision option").remove();
		//	SetValueToSelectBox(json.listOfProjectExecutives,$('#Division'));
		//	SetValueToSelectBox(json.listOfProjectExecutives,$('#SubDivision'));
			
		   $("#Division").val(json.AUTH_EXEC_CODE+" - "+json.AUTH_EXEC_DESCRIPTION);
		   $("#SubDivision").val(json.MANAGING_EXEC_CODE+" - "+json.MANAGING_EXEC_DESCRIPTION);
		  // alert("-"+json.MANAGING_EXEC_CODE+"-");
		   $("#DateComnced").val(json.COMN_DATE);
		   $("#WorkDescription").val(json.WORK_DESC);
		   $("#EnterPanID").val(json.PAN_ID);
		   
		   if(json.FILE_REF == null || json.FILE_REF == undefined)
			   $("#AccountFileRef").val("");
		   else
			   $("#AccountFileRef").val(json.FILE_REF);
		    
		/*	alert("Json " + json.SCHEDULETYPES );*/
			for(var f=0;f<json.SCHEDULETYPES.length;f++)
			{
				var temp=json.SCHEDULETYPES[f];
				$("#"+temp).show();
			}
		 
		 $("#BillPassingDetails").show(500);
		 $("#AdditionalDetailsDiv").show(500);
		
		 
		 $("#BillDetailsDiv").show(500);
		 $("#ScheduleDetailsDiv").show(500);
		 /*$("#AllocationWiseAmountDetailsDiv").show(500);*/
		 $("#RecoveryDetailsDiv").show(500);
		 $("#ButtonTable").show(500);
		 LoadScheduleDetailsGrid();
		 LoadRecoveryDetailsGrid();
		 LoadAllocationWiseAmountDetailsGrid();
		//	alert("2");
		 /*var sel=$('#recoveryCode');

								//alert(json.RECOVERYCODES.length);
			for (var i = 0; i < json.RECOVERYCODES.length; i++){	
				//alert(json.RECOVERYCODES[i][0]);
				$('<option>').text(json.RECOVERYCODES[i][0]).val(json.RECOVERYCODES[i][1]).appendTo(sel);
			}*/
			
			
		 
		// alert("1"+json.STATUS);
		 
			if(json.STATUS=='R')
			{
				$("#AlreadyExistsMessage").html(" Bill Returned");
				$('#RecoveryDetailsPager').hide();
				$('#rePassTd').hide();
				$("#AddButton").hide();
				$('#billStatus').val('R');
				$(".objectButton").hide();
				$("#passBut").hide();//Added on 1stAug 2014
			/*	$('#BillReturnDetailsDiv').show();*/
			}
			else if(json.STATUS=='7')
			{
				$("#AlreadyExistsMessage").html("CO7 is already Generated ");
				$('#RecoveryDetailsPager').hide();
				$('#rePassTd').hide();
				$("#AddButton").hide();
				$(".objectButton").hide();
				$('#billStatus').val('7');
				$("#passBut").hide();//Added on 1stAug 2014
			}
			else if(json.STATUS=='P')
			{
				statusFlag=true;
				$('#rePassTd').show();
				$("#AlreadyExistsMessage").html("Bill already Passed ");
				$("#AddButton").show();
				$('#billStatus').val('P');
				$("#passBut").hide();
				$("#retBut").hide();
				$(".objectButton").hide();
			}
			else
			{
				statusFlag=true;
				//alert("statusFlag else"+statusFlag);
				$("#AlreadyExistsMessage").html("");
				$('#rePassTd').hide();
				$('#billStatus').val('');
			}
			if(statusFlag)
			{
				$("#PassButton").show();
				$("#ReturnButton").show();
				$("#AddButton").show();
			}
			else
			{	
				$("#AccountFileRef").attr("readonly", "readonly");
				$("#PassButton").hide();
				$("#ReturnButton").hide();
			}
	}
	else
	{
		//alert("CO6 Number Not Found");
		messageBox("CO6 Number Not Found");	
		resettem();
	}
	 $('#loader').css('visibility','hidden');
}

function LoadScheduleDetailsGrid(){
	
	var grid="#"+"ScheduleDetailsList";
	var pager="#"+"ScheduleDetailsPager";
	var code=$("#UccCode").val();

	var billNo = $("#BillNumber").val();
	//alert(grid+" "+code+" "+billNo);
	$(grid).jqGrid({
		

		url:'getEditScheduleTotal.action?strCode='+code+'&intBillNo='+billNo,
	    datatype:'xml',
	    mtype: 'Post',
		colNames:['SCHEDULE','VALUE','PERCENTAGE','TOTAL'],
       colModel:[    
           { name: 'SCHEDULE', index: 'SCHEDULE', width: '25%', sortable:false, align: 'right'} ,
           { name: 'VALUE', index: 'VALUE', width: '25%', sortable:false, align: 'right'},
           { name: 'PERCENTAGE', index: 'PERCENTAGE', width: '25%', sortable:false, align: 'right'},
           { name: 'TOTAL', index: 'TOTAL', width: '25%', align: 'right', sortable:false, formatter:'number', formatoptions:{decimalPlaces: 2}}  
       ],
       rownumbers: true,
       pagination: true,
       pager: pager,
       rowNum:30,
       rowlist:[10, 20],
       viewrecords:true,
       caption:'Schedule Details For All Schedules',
       width: callSmallGridWidth(),
       height: 100
        
	 });
	$(grid).setGridParam({ 
		url:'getEditScheduleTotal.action?strCode='+code+'&intBillNo='+billNo,
		      loadonce:false
			}).trigger("reloadGrid");
		
	}
