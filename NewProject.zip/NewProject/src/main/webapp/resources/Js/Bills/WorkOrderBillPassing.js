



function LoadAllocationWiseAmountDetailsGrid()
{var code=$("#UccCode").val();

var billNo = $("#BillNumber").val();
var grid="#"+"AllocationWiseAmountDetailsList";
	
$(grid).jqGrid({
		url:'LoadAllocationWiseAmountDetails.action?strCode='+code+'&intBillNo='+billNo,
		datatype:'xml',
	    mtype: 'Post',
		colNames: ['Allocation','Amount'],
       colModel: [
             { name: 'Allocation', index: 'Allocation',width: 350, align: 'right'},
             { name: 'Amount', index: 'Amount',width: 350, align: 'right'}
             
           ],
           rownumbers: true,
           pagination: true,
           pager: '#AllocationWiseAmountDetailsPager',
           rowNum:30,
           rowlist:[10, 20],
           viewrecords:true,
           shrinkToFit:false,
           width: callSmallGridWidth(),
           height: 150,
           loadonce: false,
        caption:'Allcation details Of Bill '
        
       
     });
$(grid).setGridParam({ 
	url:'LoadAllocationWiseAmountDetails.action?strCode='+code+'&intBillNo='+billNo,
		 loadonce:false
		}).trigger("reloadGrid");
//	$(grid).setGridParam({ 
//		url:'LoadAllocationWiseAmountDetails.action?strCode='+code+'&intBillNo='+billNo,
//		
//			 loadonce:false
//			}).trigger("reloadGrid");
	
}
function LoadRecoveryDetailsGrid()
{
	var grid="#"+"RecoveryDetailsList";
	var pager="#"+"RecoveryDetailsPager";
	var workOrderNo=$("#workOrderNo").val();

	var billNo = $("#BillNumber").val();
	//alert(grid+" "+code+" "+billNo);
	$(grid).jqGrid({
		

		url:'getWorkOrderRecoveryDetails.action?workOrderNo='+workOrderNo+'&intBillNo='+billNo,
	    datatype:'xml',
	    mtype: 'Post',
		colNames:['RECOVERY ID','RECOVERY CODE','RECOVERY DESCRIPTION','INDICATOR','PERCENTAGE','RECOVERY AMOUNT','ALLOCATION'],
       colModel:[    
           { name: 'RECOVERYID', index: 'RECOVERYID', sortable:false, align: 'right',hidden:true}, 
           { name: 'RECOVERYCODE', index: 'RECOVERYCODE', sortable:false, align: 'center'} ,
           { name: 'RECOVERYDESCRIPTION', index: 'RECOVERYDESCRIPTION', sortable:false, align: 'center'},
           { name: 'INDICATOR', index: 'INDICATOR' , sortable:false, align: 'center'} ,
           { name: 'PERCENTAGE', index: 'PERCENTAGE' , sortable:false, align: 'right'},
           { name: 'RECOVERYAMOUNT', index: 'RECOVERYAMOUNT', sortable:false, align: 'right'}   ,
           { name: 'ALLOCATION', index: 'ALLOCATION', sortable:false, align: 'right'}   
       ],
       rownumbers: true,
       pagination: true,
       pager: pager,
       rowNum:30,
       rowlist:[10, 20],
       viewrecords:true,
       caption:'Recovery Details',
       shrinkToFit:false,
       width: callSmallGridWidth(),
       height: 100,
       loadonce: true
	  
	 });
	$(grid).setGridParam({ 
		url:'getWorkOrderRecoveryDetails.action?workOrderNo='+workOrderNo+'&intBillNo='+billNo,
			 loadonce:false
			}).trigger("reloadGrid");
		
}
function AddNew() 
{ 
	
	if($('#recoveryCode').val()==-1)
	{
    	   messageBox("Please select the Recovery Code");
    	   return false;
    }
       if($('#indicator').val()=='--Select--'){
       
    	   messageBox("Please select the Indicator Code");
    	   return false;
       }
      
       if($('#AllocationCode').val()=='-1'){
           
    	   messageBox("Please select the Allocation Code");
    	   return false;
       }
       if($('#indicator').val()=='P'&& $('#percentage').val()=='' )
       {
    	   messageBox("Please Enter The Percentage Value");
    	   return false;
       }
       
       var str = $('#recoveryAmount').val();
       var regStr= /^[+]?[0-9]+(\.[0-9]+)?$/;
       if(!regStr.test(str)){
    	   messageBox("Please enter a valid recovery amount");
    	   return false;
       }
       if(flag == 1)
       {
    	   
    	   return;
       }
       
       SaveRecovery();

}
function WriteOnField(json)
{
	/*alert("object o json "+ json);*/
	//alert("PMBILHID  "+json.PMBILHID);
	if(json == null)
	{
		alert("Improper data found for this bill");	
		resettem();
	}
	if(json.FoundMessage=="Found")
	{
		$("#CO6Date").val(json.Co6Date); 
		$("#VC").val(json.VC);
		 $("#UccCode").val(json.UccCode); 
		 $("#BillNumber").val(json.BillNo);
		 $("#BillType").val(json.billType); 
		 $("#AgreementNo").val(json.AgreementNo);
		 $("#PrevBillNumber").val(json.PrevBillNo);
		 $("#PrevBillDate").val(json.PrevBillDate);
		 $("#AgreementDate").val(json.AGREEMENT_DATE);
		 $("#ProjectCode").val(json.PROJ_CODE);
		 $("#ProjectName").val(json.PROJ_NAME);
		 $("#VoucherNo").val(json.VOC_NO);
		 $("#VoucherDate").val(json.VOC_DT);
		 $("#BankCode").val(json.BankCode);
		 $("#ContractorCode").val(json.CONTRACTOR_CODE);
		 $("#ContractorName").val(json.CONTRACTOR_NAME);
		 $("#CurrentBillValue").val(json.CURR_W_VAL);
		 $("#MeasuredBy").val(json.MEAS_BY_CODE+"-"+json.MEAS_BY_DESCRIPTION);
		 $("#MeasuredOnDate").val(json.MEA_FRM_DT);
		 $("#TestCheckedBy").val(json.TST_CODE+"-"+json.TST_DESCRIPTION);
		 $("#TestCheckedOnDate").val(json.TST_CHK_DT);
		 $("#CertifiedBy").val(json.CERT_BY_CODE+"-"+json.CERT_BY_DESCRIPTION);
		$("#CumulativeAmt").val(json.CUM_W_VAL);
		$("#CumulativeBillAmt").val(0);
		 $("#MBNumber").val(json.MB_NO);
		 $("#MBPageNumber").val(json.MB_PG_NO);
		 $("#BillDate").val(json.BILL_DT);
		 $("#AgreementCurrency").val(json.AGREEMENT_CURR);
		  $("#TotalforAgreement").val(json.AGREEMENT_VALUE);
		  $("#NetPayable").val(json.AMT_PYABLE);
		  $("#TotalRecoveries").val(json.RECOVERY);
		  $("#IFSCCode").val(json.IFSCCODE);
		  $("#AccountNo").val(json.ACCOUNTNO);
		   $("#CertificationCode").val(json.CERT_CD+" - "+json.SDESC);
		   $("select#Division option").remove();
			$("select#SubDivision option").remove();
		//	SetValueToSelectBox(json.listOfProjectExecutives,$('#Division'));
		//	SetValueToSelectBox(json.listOfProjectExecutives,$('#SubDivision'));
			
		   $("#Division").val(json.AUTH_EXEC_CODE+" - "+json.AUTH_EXEC_DESCRIPTION);
		   $("#SubDivision").val(json.MANAGING_EXEC_CODE+" - "+json.MANAGING_EXEC_DESCRIPTION);
		  // alert("-"+json.MANAGING_EXEC_CODE+"-");
		   $("#DateComnced").val(json.COMN_DATE);
		   $("#WorkDescription").val(json.WORK_DESC);
		   $("#EnterPanID").val(json.PAN_ID);
			 $("#AccountFileRef").val(json.FILE_REF);
			 $("#bilhId").val(json.PMBILHID);
			 $("#workOrderNo").val(json.WORKORDERNO);
			 
			 
		/*	alert("Json " + json.SCHEDULETYPES );*/
			
			for(var f=0;f<json.SCHEDULETYPES.length;f++)
			{
				var temp=json.SCHEDULETYPES[f];
				$("#"+temp).show();
			}
		 
		 $("#BillPassingDetails").show(500);
		 $("#AdditionalDetailsDiv").show(500);
		
		 
		 $("#BillDetailsDiv").show(500);
		 $("#ScheduleDetailsDiv").show(500);
		 /*$("#AllocationWiseAmountDetailsDiv").show(500);*/
		 $("#RecoveryDetailsDiv").show(500);
		 $("#ButtonTable").show(500);
		 LoadScheduleDetailsGrid();
		 LoadRecoveryDetailsGrid();
		//	LoadAllocationWiseAmountDetailsGrid();
		//	alert("2");
		 /*var sel=$('#recoveryCode');

								//alert(json.RECOVERYCODES.length);
			for (var i = 0; i < json.RECOVERYCODES.length; i++){	
				//alert(json.RECOVERYCODES[i][0]);
				$('<option>').text(json.RECOVERYCODES[i][0]).val(json.RECOVERYCODES[i][1]).appendTo(sel);
			}*/
			
			
		 var statusFlag=false;
		 
			if(json.STATUS=='R'){
			$("#AlreadyExistsMessage").html(" Bill Returned");
			
			}
			else if(json.STATUS=='7')
				{
				$("#AlreadyExistsMessage").html("CO7 is already Generated ");
			
				}
			else if(json.STATUS=='P')
				{
				$("#AlreadyExistsMessage").html("Bill already Passed ");
				
				}
			else{
				statusFlag=true;
				$("#AlreadyExistsMessage").html("");
				
			}
			$("#AccountFileRef").removeAttr('readonly');
			if(statusFlag)
				{
				$("#PassButton").show();
				$("#ReturnButton").show();
				$("#AddButton").show();
			
				}
			else
			{	$("#AccountFileRef").attr("readonly", "readonly");
				$("#PassButton").hide();
				$("#ReturnButton").hide();
				$("#AddButton").hide();
				
				
			}
		
	}
	else
	{
		alert("CO6 Number Not Found");
	}
	 $('#loader').css('visibility','hidden');
	
}
function populateRecoveryDesc(id)
{
	$("#indicator").val('--Select--');
$("#recoveryDescription").val(id.value);
$("#percentage").val('');
$("#recoveryAmount").val('');

}
function enableOrDisablePercentage(){
	
	if($("select#indicator option:selected").val() == "P"){
		$("#percentage").removeAttr('disabled');
		$("#recoveryAmount").attr("readonly", "readonly");
		$("#recoveryAmount").val('');
	}else if ($("select#indicator option:selected").val() == "V"){
		$("#recoveryAmount").removeAttr('readonly');
		$("#percentage").attr('disabled','true');
		$("#percentage").val('');
		$("#recoveryAmount").val('');
		
		//calculateRecoveryAmtForValue();
	} 
}
function calculateRecoveryAmtForPercentage(){
	var recoveyPercentage = $('#percentage').val();
	var recoveryAmt =($('#CurrentBillValue').val()) * (recoveyPercentage / 100);
	$('#recoveryAmount').val(recoveryAmt.toFixed(2));
}

function SetValueToSelectBox(List,id)
{
	
	var sel = id;
	
	$('<option>').text("--Select--").val("-1").appendTo(sel);
		for (var i = 0; i < List.length; i++)
		{
		  var e= List[i][0];
		 var v=List[i][0]+" - "+List[i][1];
		// alert(v);
		$('<option>').text(v).val(e).appendTo(sel);
		}
}



function LoadScheduleDetailsGrid(){
	
	var grid="#"+"ScheduleDetailsList";
	var pager="#"+"ScheduleDetailsPager";
	var code=$("#UccCode").val();

	var billNo = $("#BillNumber").val();
	var workOrderNo=$("#workOrderNo").val();
	//alert(grid+" "+code+" "+billNo);
	$(grid).jqGrid({
		

		url:'getScheduleDetailsTotal.action?schedule='+workOrderNo, 
	    datatype:'xml',
	    mtype: 'Post',
		colNames:['SCHEDULE','VALUE','PERCENTAGE','TOTAL'],
       colModel:[    
           { name: 'SCHEDULE', index: 'SCHEDULE', width: '25%', sortable:false, align: 'right'} ,
           { name: 'VALUE', index: 'VALUE', width: '25%', sortable:false, align: 'right'},
           { name: 'PERCENTAGE', index: 'PERCENTAGE', width: '25%', sortable:false, align: 'right'},
           { name: 'TOTAL', index: 'TOTAL', width: '25%', align: 'right', sortable:false, formatter:'number', formatoptions:{decimalPlaces: 2}}  
       ],
       rownumbers: true,
       pagination: true,
       pager: pager,
       rowNum:30,
       rowlist:[10, 20],
       viewrecords:true,
       caption:'Schedule Details For All Schedules',
       width: callSmallGridWidth(),
       height: 100
        
	 });
	$(grid).setGridParam({ 
		url:'getEditScheduleTotal.action?strCode='+code+'&intBillNo='+billNo,
		      loadonce:false
			}).trigger("reloadGrid");
		
	}
