var flag=0;

function isDateValid(toCheckDate)
{
	 	var Date_array=toCheckDate.split('/');
	    var d=Date_array[0];
		var m=Date_array[1];
		var y=Date_array[2];
		var months = [31,28,31,30,31,30,31,31,30,31,30,31];
		if(!(d>0 && m>0 && y>0 && m<=12 && (d<=months[m-1] || (m==2 && d==29 && ((y%4==0&& y%100!=0) || (y%400==0)))) )){
			return false;
		}  
		else {
			return true;
		}
}

function forward(){ 	 
	if($("#sanctionNo").val().length==0){
   		   alert("Please enter the  Sanction No.");
   		   $("#sanctionNo").focus();
   		   return false;
   		}
   	       
	  
   	    if($("#typeofequId option:selected").val()=="-1"){
			 alert("Please select Type of Equipment.");
			 $("#typeofequId").focus();
			 return false;
		   }	 
   	       
	  
	        if($("#yearOfPro").val().length==0){
		     alert("Please enter the Year Of Procurement ");
		     $("#yearOfPro").focus();
		    return false;
		    }
	  
	      if($("#codalLife").val().length==0){
		   alert("Please enter the Year Codal Life Asset");
		   $("#codalLife").focus();
		    return false;
		 }
	  
	  if($("#natureOfRpr").val().length==0){
		   alert("Please enter the Nature Of Repair");
		   $("#natureOfRpr").focus();
		   return false;
		}
	  
	  var dat1= $("#sanctionDate1").val();
	   if(!isDateValid(dat1)){
		  alert("Enter Valid Date");
		  $("#sanctionDate1").focus();
		  return false;
	     }
	  
	  
	  
	  if(flag==1){ //In Update Mode
		  $.post('editRepairOfcEqp.action?id='+$("#rowIdVal").val()+'&sanctionNo='+$("#sanctionNo").val()+'&sanctionDate1='+$("#sanctionDate1").val()+'&typeofequ='+$("#typeofequId option:selected").val()+'&yearOfPro='+$("#yearOfPro").val()+'&codalLife='+$("#codalLife").val()+'&natureOfRpr='+$("#natureOfRpr").val()+'&voucherNo='+$("#voucherNo").val()+'&sanctionAmnt='+$("#sanctionAmnt").val()+'&firmName='+$("#firmName").val()+'&allocationCode='+$("#allocationCode").val()+"&projectCode="+$("#projectCode").val()+'&iGecid='+$("#iGecid").val()+'&neft='+$("#neft").val(),
				  function(data){
			  $("#messagebox").show();
			 
			  if(data.message=="Saved"){
				  document.getElementById("message").innerHTML = 'Data Updated.';
				  $("#rprOfcEquipList").trigger("reloadGrid");
			       
			  }else if(data.message=="Error"){
				  document.getElementById("message").innerHTML = 'Error';
			  }
			  flag = 0;
			
		
		       },"json");
		 
		  clearData();
			return false;
		 

		}
	$.post('saveRepairEquip.action?sanctionNo='+$("#sanctionNo").val()+'&sanctionDate1='+$("#sanctionDate1").val()+'&typeofequId='+$("#typeofequId option:selected").val()+'&yearOfPro='+$("#yearOfPro").val()+'&codalLife='+$("#codalLife").val()+'&natureOfRpr='+$("#natureOfRpr").val()+'&sanctionAmnt='+$("#sanctionAmnt").val()+'&firmName='+$("#firmName").val()+'&allocationCode='+$("#allocationCode").val()+"&projectCode="+$("#projectCode").val()+'&iGecid='+$("#iGecid").val()+'&voucherNo='+$("#voucherNo").val()+'&neft='+$("#neft").val(),
		function(result){
		$("#messagebox").show();
		clearData();
		if(result.message=="Error"){
			document.getElementById("message").innerHTML =result.message;
		}else if(result.message=="Saved"){
			document.getElementById("message").innerHTML ="Data Saved";
			
		}
		
		$("#rprOfcEquipList").trigger("reloadGrid");
		
	  /*location.reload();
	  document.getElementById('submitForm').reset();*/
	//$("#list").trigger("reloadGrid");
    },"json");
	  
	  
	//  return true;
  }
	function close(){
		$("#messagebox").hide();
	}
   function clearData(){
	   $("#sanctionNo").val("");
		$("#yearOfPro").val("");
		$("#codalLife").val("");
		$("#natureOfRpr").val("");
		$("#sanctionDate1").val("");
		$("#sanctionAmnt").val("");
		$("#firmName").val("");
		$("#allocationCode").val("");
		$("#voucherNo").val("");
		$('#projectCode option:first').attr('selected', 'selected');
		$('#iGecid option:first').attr('selected', 'selected');
		$('#typeofequId option:first').attr('selected', 'selected');
		$("#neft").val("");


   }
$(document).ready(function() {
	alert("in form load");
	//$("#sanctionNo").numberLettersAndSpaceAndBackspace();
	$("#yearOfPro").numbers();
	$("#codalLife").numbers();
	//$("#natureOfRpr").numberLettersAndSpaceAndBackspace();
	
	
	$('#sanctionDate1').datepicker({
	   	 dateFormat: 'dd/mm/yy',
	   	showOn: 'both',
        buttonImage: 'images/calendar.gif',
        buttonImageOnly: true,
	   	 changeYear : true,
  	     changeMonth : true
  });
});
function createGrid(){
	
	 var delSettings ={
			  // define settings for Delete 
			  mtype: "post",	  
			  onclickSubmit: function (rp_ge, rowid) {	
				 
			             rp_ge.url = "deleteRprOfcEqu.action?repairToEqpId="+rowid;
			           
			             $("#rprOfcEquipList").trigger("reloadGrid");
			  }
		  };		
	 
	   $("#rprOfcEquipList").jqGrid({
	    	datatype:'xml',
	 	  	mtype: 'Post', 		
			url:"rprOfceEquipView.action?action=fetchData",	  	   
			colNames:['Sanction No','Sanction Date','Type of equipment','Typeofequ','Year of procurement','Codal life','Nature of repair','Firm Name','Sanction Amount','Voucher No','Allocation','Project Code','Executive Code','Executive Id','Project Id','NEFT'],
			colModel:[
	          	{ name: 'sanctionNo', index: 'sanctionNo',width : 108, align:'left',editable:true} ,
	          	{ name: 'sanctionDate',index: 'sanctionDate',width : 117,formatter:'date',editable:true},
	   			{ name: 'typeofequ',index: 'typeofequ',width : 144,editable:false},
	    		{ name: 'typeofequId', index: 'typeofequId',width :-2 ,align: 'left',editable:true ,edittype:'select', editoptions:{dataUrl:'getRprOfcGencodes.action'}},
	    		{ name: 'yearOfPro', index: 'yearOfPro',width : 128 ,align: 'left',editable:true} ,
	    		{ name: 'codalLife',index: 'codalLife',width :95,editable:true},
	    		{ name: 'natureOfRpr', index: 'natureOfRpr',width :120,align:'left',editable:true} ,
	    		{ name: 'firmName', index: 'firmName',width :100,align:'left',editable:true} ,
	    		{ name: 'sanctionAmnt', index: 'sanctionAmnt',width :150,align:'left',editable:true} ,
	    		{ name: 'voucherNo', index: 'voucherNo',width :120,align:'left',editable:true} ,
	    		{ name: 'allocation', index: 'allocation',width :120,align:'left',editable:true} ,
	    		{ name: 'projectCode', index: 'projectCode',width :150,align:'left',editable:true} ,
	    		{ name: 'executiveCode', index: 'executiveCode',width :150,align:'left',editable:true} ,
	    		
	    		{ name: 'execId', index: 'execId',width :150,align:'left',editable:false,hidden:true} ,
	    		{ name: 'projId', index: 'projId',width :150,align:'left',editable:false,hidden:true} ,
	    		{ name: 'neft', index: 'neft',width : 150, align:'left',editable:true}
	 		 ],
	 	   rowNum:10,
		   loadonce:false,
		   rownumbers:true,
	 	   rowList:[5,10,20],
		   cellEdit: false, 
		   viewrecords:true,
		   caption:'Repair Office Equipment Detail',		   
		   pager: '#pager',
		   width: 795,
		   height: 'auto',
		   shrinkToFit:false,
		   closeAfterAdd:true,
	       closeAfterEdit:true,
	       reloadAfterSubmit:true,
		    cellsubmit: 'clientArray',
		    ondblClickRow: function(rowid, ri, ci) {
		        var p = grid[0].p;
		        if (p.selrow !== rowid) {
		            // prevent the row from be unselected on double-click
		            // the implementation is for "multiselect:false" which we use,
		            // but one can easy modify the code for "multiselect:true"
		            grid.jqGrid('setSelection', rowid);
		        }					       
		        grid.jqGrid('editGridRow', rowid, editSettings);
		    }
		    
		 });
	 	
	 	jQuery("#rprOfcEquipList").navGrid('#pager',{ edit:false,add:false,del:true,search:true },{},{},delSettings,{closeAfterSearch:true})
	 	.navButtonAdd('#pager',{ caption:"Edit", buttonicon:"ui-icon-pencil",position:"first",title:'Edit',
		 	onClickButton:function(){	
		 		flag=1;
	        	var rowid = $("#rprOfcEquipList").jqGrid('getGridParam', 'selrow');	        	
	        	if(rowid==null){
	        		alert("Please select Row.");
	        		return;
		        }
	        	var gridRow = $("#rprOfcEquipList").getRowData(rowid);
	        	$("#rowIdVal").val(rowid);
	        	$("#sanctionNo").val(gridRow.sanctionNo);
	    		$("#sanctionDate1").val(gridRow.sanctionDate);
	    		$("#typeofequId").val(gridRow.typeofequId);
	    		$("#yearOfPro").val(gridRow.yearOfPro);
	    		$("#codalLife").val(gridRow.codalLife);
	    		$("#natureOfRpr").val(gridRow.natureOfRpr);
	    		
	    		$("#sanctionAmnt").val(gridRow.sanctionAmnt);
	    		$("#firmName").val(gridRow.firmName);
	    		$("#allocationCode").val(gridRow.allocation);
	    		$("#voucherNo").val(gridRow.voucherNo);
	    		$("#projectCode").val(gridRow.projId);
	    		$("#iGecid").val(gridRow.execId);
	    		$("#neft").val(gridRow.neft);
		 	}
		});

}


