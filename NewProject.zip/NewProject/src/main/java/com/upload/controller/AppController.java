package com.upload.controller;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.validation.Valid;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.upload.model.FileBucket;
import com.upload.model.OodoData;
import com.upload.model.Read1;
import com.upload.model.Read2;
import com.upload.model.Read31;
import com.upload.model.UserDocument;
import com.upload.service.UserDocumentService;
import com.upload.util.FileValidator;

/***********************************************************************************
 * Controller  Class to handle all the actions.
 * 
 * @author Prasanta
 * @version 1.0
 ***********************************************************************************/

@Controller
@RequestMapping("/")
public class AppController {

	
	
	@Autowired
	UserDocumentService userDocumentService;
	
	@Autowired
	MessageSource messageSource;

	@Autowired
	FileValidator fileValidator;
	
	
	
	@InitBinder("fileBucket")
	protected void initBinder(WebDataBinder binder) {
	   binder.setValidator(fileValidator);
	}
	
	
	
	/**
	 The method will execute for the first time when the application runs.
	 */

	@RequestMapping(value="/", method= RequestMethod.GET)
	public ModelAndView loadJsp(ModelMap model1){
		
		
		
		FileBucket fileModel = new FileBucket();
		model1.addAttribute("fileBucket", fileModel);
		
		return new ModelAndView("/admin/managedocument",model1);
		
	}
	
	/**
	 The method will execute for the {adddocument GET} action .
	 */
	@RequestMapping(value = { "/adddocument" }, method = RequestMethod.GET)
	public String addDocuments( ModelMap model, HttpServletRequest req , HttpServletResponse res) {
		
		

		FileBucket fileModel = new FileBucket();
		model.addAttribute("fileBucket", fileModel);

		return "/admin/managedocument";
	}
	

	

	

	
	/**
	 The method will execute for the {adddocument POST} action .
	 */
	@RequestMapping(value = { "/adddocument" }, method = RequestMethod.POST)
	public ModelAndView uploadDocument(@RequestParam("file") MultipartFile file,@RequestParam("multiplefile") MultipartFile[] multiplefile,@RequestParam("file1") MultipartFile file1,@Valid FileBucket fileBucket,BindingResult result,  ModelMap model,HttpServletRequest request,
	        HttpServletResponse response) throws ServletException,IOException{
		
		
		BufferedReader br = null;
		FileReader fr = null;
		
		
		FileBucket fileModel = new FileBucket();
		model.addAttribute("fileBucket", fileModel);
		int count=0,c1=0,c2=0;
		String[] s=new String[500];
		 try{
		
	/*if (result.hasErrors()) {
			System.out.println("validation errors");
			
			
			ModelAndView mv = new ModelAndView("/admin/managedocument" , model);
			mv.addObject("Msg","Your File size is too large, Please upload files with in 5MB.");
		    return mv;
		} else  {*/
		
			String radioType=request.getParameter("new");
			System.out.println(radioType+"oooooooooooooooooooooooooooo");
			
			if(radioType.equalsIgnoreCase("new")){
			
		    System.out.println("Fetching file");
			
		    try{
		    final String FILENAME1 = "D:\\IMPSL-text\\IMSPL_313_16-17_G.T.Enterprises.txt";
			final String FILENAME2 = "D:\\IMPSL-text\\IMSPL_304_16-17_WIZERTECH INFORMATICS PVT. LTD..txt";
			
			String sCurrentLine;
			String[] s1=new String[500];
			String[] s2=new String[500];
			br = new BufferedReader(new FileReader(FILENAME1));
			int k1=0;
			while ((sCurrentLine = br.readLine()) != null) {
				sCurrentLine=sCurrentLine.trim();
				s1[k1]=sCurrentLine;
				k1++;
				//System.out.println(sCurrentLine);
			}
			//System.out.println("^^^^^^^^^^^^^^^^^^^^^^");
			br = new BufferedReader(new FileReader(FILENAME2));
			int k2=0;
			while ((sCurrentLine = br.readLine()) != null) {
				sCurrentLine=sCurrentLine.trim();
				s2[k2]=sCurrentLine;
				k2++;
				//System.out.println(sCurrentLine);
			}
			
			/*for(int i=0;i<s1.length;i++)
				if(s1[i]!=null)
					System.out.println(s1[i]);
			System.out.println("-------------------");
			for(int i=0;i<s2.length;i++)
				if(s2[i]!=null)
					System.out.println(s2[i]);*/
			
			int k=0;
			for(int i=0;i<s1.length;i++)
			{
				for(int j=0;j<s2.length;j++)
				{
					if(s1[i]!=null&&s2[j]!=null)
					{
						if(s1[i].equals(s2[j]))
						{
							if(s1[i].matches("[\u0000-\u00FF]+"))
							{
								s[k]=s1[i];
								k++;
								//System.out.println(s1[i]);
								count++;
							}
							else
							{
								//System.out.println(s1[i]+"-----------"+s2[j]);
							}
						}
					}
				}
			}
			//System.out.println(count);
			//d.method(s,count);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
			
			// creating folder for each applicant
			File theDir = new File("C:/KeywordsFinder/"+radioType);

			// if the directory does not exist, create it
			if (!theDir.exists()) {
			    boolean result1 = false;

			   
			        theDir.mkdirs();
			        result1 = true;
			          
			    if(result1) {    
			        System.out.println("DIR created");  
			    }
			}
			
		
			String destPath="C:/KeywordsFinder/"+radioType+"/"+file.getOriginalFilename().replace(" ", "_");
			
			String destPath1="C:/KeywordsFinder/"+radioType+"/"+file1.getOriginalFilename().replace(" ", "_");
			
			
			
			InputStream is = new ByteArrayInputStream(file.getBytes());
			FileOutputStream fos = new FileOutputStream(theDir+"/"+file.getOriginalFilename().replace(" ", "_"));
			int b = 0;
			while ((b = is.read()) != -1)
				fos.write(b); 
			is.close();
			fos.close();
			
			InputStream is1 = new ByteArrayInputStream(file1.getBytes());
			FileOutputStream fos1 = new FileOutputStream(theDir+"/"+file1.getOriginalFilename().replace(" ", "_"));
			int b1 = 0;
			while ((b1 = is1.read()) != -1)
				fos1.write(b1); 
			is1.close();
			fos1.close();
			
			String path=destPath+"";
			String path1=destPath1+"";
			saveDocumentNew(file,file1,path,path1);
			
			
		for(int h=0;h<2;h++)
		{
			try{
			String sCurrentLine;
			String[] s1=new String[500];
			String f="";
			int flag;
			if(h==0)
			{
				f=path;
				flag=1;
			}

			else
			{
				f=path1;
				flag=2;
			}

			fr = new FileReader(f);
			br = new BufferedReader(fr);
			//br = new BufferedReader(new FileReader(FILENAME));
			int k1=0;
			//System.out.println("==================");
			while ((sCurrentLine = br.readLine()) != null) {
				sCurrentLine=sCurrentLine.trim();
				s1[k1]=sCurrentLine;
				k1++;
				//System.out.println(sCurrentLine);
			}
			//System.out.println("-----------");
			for(int i=0;i<=s.length&&s[i]!=null;i++)
			{
				for(int j=0;j<=s1.length&&s1[j]!=null;j++)
				{
					String st1=s[i].replaceAll("\\s+","");
					String st2=s1[j].replaceAll("\\s+","");
					if(st1.equals(st2))
					{
					//System.out.println("------------"+s[i]);
						if(flag==1)
						c1++;
						if(flag==2)
							c2++;
					}
					else
					{
						//System.out.println("KKKKKKKKK"+s1[j]);
					}
				}
			}
			
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		//comparingTwoFiles(path, path1);
		if(c1==count&&c2==count)
		{
			System.out.println("Both Matched!!! Total weight="+c1);
			//String str="Document got matched as Integra invoice! Now you can process the documents"+c;
			ModelAndView mv = new ModelAndView("/admin/managedocument" , model);
			mv.addObject("Msg","Document 1 and Document 2 got matched as Integra invoice! Now you can process the documents");
		    return mv;
			//m.method1(s1);
			//System.out.println("HIII");
		}
		else if(c1==count&&c2!=count)
		{
			System.out.println("First Matched!!! Total weight="+c1);
			//String str="Document got matched as Integra invoice! Now you can process the documents"+c;
			ModelAndView mv = new ModelAndView("/admin/managedocument" , model);
			mv.addObject("Msg","Document 1 got matched as Integra invoice! Now you can process the document");
		    return mv;
		}
		else if(c2==count&&c1!=count)
		{
			System.out.println("Second Matched!!! Total weight="+c2);
			//String str="Document got matched as Integra invoice! Now you can process the documents"+c;
			ModelAndView mv = new ModelAndView("/admin/managedocument" , model);
			mv.addObject("Msg","Document 2 got matched as Integra invoice! Now you can process the document");
		    return mv;
		}
		else
		{
			System.out.println("Not matched, weight obtained="+c1+"\tActual weight="+count);
			ModelAndView mv = new ModelAndView("/admin/managedocument" , model);
			mv.addObject("Msg","Documents didnt get matched! Try again before processing");
		    return mv;
			
		}
			
			
			
			}else if(radioType.equalsIgnoreCase("processing")){
				
				System.out.println("Fetching file");
				
				
				
				
				// creating folder for each applicant
				File theDir = new File("C:/KeywordsFinder/"+radioType);

				// if the directory does not exist, create it
				if (!theDir.exists()) {
				    boolean result1 = false;

				   
				        theDir.mkdirs();
				        result1 = true;
				          
				    if(result1) {    
				        System.out.println("DIR created");  
				    }
				}
				/*File destination = new File(theDir+"/"+file.getOriginalFilename().replace(" ", "_")); 
				String destPath="C:/KeywordsFinder/processing/"+file.getOriginalFilename().replace(" ", "_");*/
				
				
				
				for(int a=0; a<multiplefile.length; a++){
					MultipartFile multiplefile1=multiplefile[a];
					
					
					File destination = new File(theDir+"/"+multiplefile1.getOriginalFilename().replace(" ", "_")); 
					String destPath="C:/KeywordsFinder/processing/"+multiplefile1.getOriginalFilename().replace(" ", "_");
					
					InputStream is = new ByteArrayInputStream(multiplefile1.getBytes());
					FileOutputStream fos = new FileOutputStream(theDir+"/"+multiplefile1.getOriginalFilename().replace(" ", "_"));
					int b = 0;
					while ((b = is.read()) != -1)
						fos.write(b); 
					is.close();
					fos.close();
					
					String path=destPath+"";
					saveDocument(multiplefile1,path);
					
					Mymethod test = new Mymethod();
					OodoData masterObj= new OodoData();
					
					BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
					fr = new FileReader(destPath);
					br = new BufferedReader(fr);
					String[] s1=new String[200];
					String[] s2=new String[200];
					String[] s5=new String[200];
					String[] s8=new String[200];
					String[] s9=new String[200];
					String[] s0=new String[200];
					String[] s11=new String[200];
					//String[] st0=new String[200];
					String[] st1=new String[200];
					String[] st2=new String[200];
					String sCurrentLine;
					int z0=0, z1=0,z2=0,z3=0;
					br = new BufferedReader(new FileReader(destPath));
					int k=0;
					//ResultSet rs1=stmt.executeQuery("SELECT * FROM key_words");
					while ((sCurrentLine = br.readLine()) != null) {
						k++;
						if(sCurrentLine.startsWith("PURCHASE ORDER No."))
						{
							z0=k;
						}
						if(sCurrentLine.startsWith("End-customer"))
						{
							z1=k;
							//System.out.println(z1);
						}
						if(sCurrentLine.startsWith("PRODUCTS & SERVICES ORDER INFORMATION:"))
						{
							z2=k;
						}
						if(sCurrentLine.startsWith("Payment Terms:"))
						{
							z3=k;
						}
						
						//sCurrentLine=sCurrentLine.trim();
						//String[] s=sCurrentLine.split("\\s+");
						s1[k]=sCurrentLine;
						
						System.out.println(sCurrentLine);
					}
					
					int x=0;
					String[] e=s1[z0].split(":");
					String[] e1=e[1].split("\t+");
					for(int i=z0;i<z0+1;i++)
					{
						
						e1[0]=e1[0].trim().replace(",","");
						//System.out.println(e1[0]);
						e1[1]=e1[1].replace("Dated","").trim();
						masterObj.setC1(e1[0]);
						masterObj.setC2(e1[1]);
						
					}
					int k1=0;
					String hh1="",hh="";
					String h1="",h2="",h3="",h4="",h5="",h6="",h7="",h8="",h9="",h10="",h11="",h12="",h13="",h14="",h15="",h16="",h17="",h18="",h19="";
					for(int i=z1+1;i<z2;i++)
					{
						if(s1[i].startsWith("Company Name"))
						{
							test.method1(s1[i]);
							/*System.out.println(test.s2);
							System.out.println(test.s5);*/
							h1=test.s2;
							masterObj.setC3(test.s2);
							h2=test.s5;
							masterObj.setC4(test.s5);
						}
						if(s1[i].startsWith("Address 1"))
						{
							test.method1(s1[i]);
							
							masterObj.setC5(test.s2);
							h3=test.s2;
							masterObj.setC6(test.s5);
							h4=test.s5;
						}
						if(s1[i].startsWith("Address 2"))
						{
							test.method1(s1[i]);
							
							
							masterObj.setC7(test.s2);
							h5=test.s2;
							masterObj.setC8(test.s5);
							h6=test.s5;
						}
						if(s1[i].startsWith("City & Country"))
						{
							test.method1(s1[i]);
							
							masterObj.setC9(test.s21);
							h7=test.s21;
							//System.out.println("main    "+test.s21+"   hh "+test.s51);
							
							masterObj.setC10(test.s51);
							h8=test.s51;
							//System.out.println("main    "+test.s2+"   hh "+test.s5);
							
							masterObj.setC11(test.s2);
							h9=test.s2;
							masterObj.setC12(test.s5);
							h10=test.s5;
							
						}
						if(s1[i].startsWith("State & Postal"))
						{
							test.method1(s1[i]);
							//ps.setString(7,test.s21);
							masterObj.setC13(test.s21);
							h11=test.s21;
							System.out.println(test.s21+test.s51);
							//ps.setString(11,test.s51);
							masterObj.setC14(test.s51);
							h12=test.s51;
							//ps.setString(17,test.s2);
							System.out.println(test.s2+test.s5);
							//ps.setString(22,test.s5);
							//ps.setString()
							
							masterObj.setC15(test.s2);
							h13=test.s2;
							masterObj.setC16(test.s5);
							h14=test.s5;
						}
						if(s1[i].startsWith("Contact Name &"))
						{
							test.method1(s1[i]);
							//ps.setString(8,test.s21);
							masterObj.setC17(test.s21);
							h15=test.s21;
							System.out.println(test.s21+test.s51);
							//ps.setString(19,test.s51);
							//ps.setString(19,test.s2);
							masterObj.setC18(test.s2);
							h16=test.s2;
							System.out.println(test.s2+test.s5);
							//ps.setString(22,test.s5);
							//ps.setString()
						}
						if(s1[i].startsWith("email address"))
						{
							test.method1(s1[i]);
							//ps.setString(20,test.s2);
							masterObj.setC19(test.s2);
							h17=test.s2;
							System.out.println(test.s2);
						//	ps.setString(9,test.s5);
							masterObj.setC20(test.s5);
							h18=test.s5;
							System.out.println(test.s5);
						}
						
						if(s1[i].startsWith("Phone &"))
						{
							test.method1(s1[i]);
							
								hh1=test.s21.replaceAll("^\\s+|\\s+$", "");
								//double b=Double.valueOf(hh);
								System.out.println(test.s21);
							//BigDecimal xx=BigDecimal.valueOf(b);
							//System.out.println(xx);
						//	ps.setString(10,hh1);
							
							masterObj.setC21(hh1);
							
							
							System.out.println(test.s21+test.s51);
							
							
								hh=test.s2.replaceAll("^\\s+|\\s+$", "");
							//	double b=Double.valueOf(hh);
								System.out.println(test.s2);
							//BigDecimal xx=BigDecimal.valueOf(b);
							//System.out.println(xx);
							//ps.setString(21,hh);
							masterObj.setC22(hh);
			
						}
						
					}
					
					
					
					String ss="",ss1="";
					for(int i=z0+2;i<z1-1;i++)
					{
						
						//System.out.println(s1[i]);
						String[] st0=s1[i].split("\\t{2}+");
						
						st1[k1]=st0[0];
						System.out.println(st1[k1]);
						ss=ss+st1[k1];
						System.out.println(st0[1]);
						st2[k1]=st0[1];
						ss1=ss1+st2[k1];
						k1++;
						System.out.println(st2[i]+st1.length);
						System.out.println(i);
					}

					
					System.out.println(ss);
					//ps.setString(36,ss);
					masterObj.setC23(ss);
				
					System.out.println(ss1);
					//ps.setString(37,ss1);
					masterObj.setC24(ss1);
					
					String q1="",q2="",q3="",q4="",q5="",q6="",q7="",q8="",q9="";
					for(int i=z1+1;i<z2;i++)
					{
						if(s1[i].contains(":"))
						{
							String[] s3=s1[i].split(":");
							if(s3[0].contains("&"))
							{
								StringBuilder sb= new StringBuilder();
								String mainString=s1[i];
								String[] fst=mainString.split(":");
								String [] secnd= fst[1].split("\t");
								//System.out.println(secnd[1]+" "+secnd[2]+"  Part 1");
								for(int i1=3;i1<secnd.length;i1++){
									sb.append(secnd[i1]);
									
									sb.append(" ");
								}
								System.out.println(sb.toString());
								String[] xx=sb.toString().split("\\s{2}+");
								try{
								System.out.println(xx[0]);
								System.out.println(xx[1]);
								}
								catch(Exception es)
								{}
						      }

							else
							{
								
								String[] s4=s3[1].split("\\s{2,}");
								s2[i]=s4[0];
								s11[i]=s3[0];
								try{
									System.out.println(s2[i]);
									System.out.println(s4[1]);
									s5[i]=s4[1];	
									}
								catch(Exception es)
								{}
							}
						}
						else{
							if(i==z2-2)
							{
						System.out.println(s1[i]);
						String[] sd=s1[i].split("");
						System.out.println(sd[0]);
						System.out.println(sd[1]);
						String[] sd1=s1[i].split("Reseller account");
						try{
						System.out.println(sd1[0]);
						sd1[0]=sd1[0].replace("Contract Start Date","");
						System.out.println(sd1[0]);
						//ps.setString(26,sd1[0]);
						masterObj.setC25(sd1[0]);
						q1=sd1[0];
						System.out.println(sd1[1]);
						sd1[1]=sd1[1].trim().replace("#","");
						//ps.setString(27,sd1[1]);
					    masterObj.setC26(sd[1]);
					    q2=sd[1];
						System.out.println(sd1[1]);
						}
						catch(Exception es)
						{
							//System.out.println(e);
						}
							}
						}
						x=i;
					}
					
					
					for(int i=0;i<x;i++)
					{
						try{
						//if(s2[i]!=null)
						
							//System.out.println(s2[i]);
							if(s1[i].contains("Acct# or Red Hat Network Login (if known)"))
							{
							//	System.out.println(s5[i]+"hi");
								String[] s51=s1[i].split(":",2);
								System.out.println(s51[0]+"jj"+s51[1]);
								if(s51[1].contains("Acct")||s51[1].contains("Account")||s51[1].contains("account"))
								{
									
									//String[] s52=s51[1].split("#");
									
									//System.out.println(s52[1]);
									//ps.setString(23,s52[1]);
									if(s51[1].contains("Reseller P.O"))
									{
										 String[] mm1=s51[1].split("Reseller P.O");
										 //ps.setString(23,mm1[0]);
										 masterObj.setC27(mm1[0]);
										 q3=mm1[0];
									}
									else
									//ps.setString(23,s51[1]);
									{
										masterObj.setC28(s51[1]);
									q4=s51[1];
									}
								}
								else
									//ps.setString(23,"");
								masterObj.setC27("");
								   
								if(s51[1].contains("Contract"))
								{
									String[] s52=s51[1].trim().split("#");
									//System.out.println(s52[1].trim().replace(s52[1].startsWith("Reseller P.O.","")));
									//int dd=Integer.valueOf(s52[1].trim());
									//sSystem.out.println(dd);
									//ps.setString(24,s52[1]);
									masterObj.setC28(s52[1]);
									q4=s52[1];
								}
								else
								{
									//ps.setInt(24,0);
									masterObj.setC28("");
									q4="";
								}
								
								if(s51[1].contains("Reseller P.O."))
								{
								String[] s53=s51[1].split("Reseller P.O.");
								System.out.println(s51[1]);
								try{
									
								s53[1]=s53[1].replace(",","");
								System.out.println(s53[1]);
								
								//ps.setString(25,s53[1]);
								masterObj.setC29(s53[1]);
								q5=s53[1];
								}
								
								catch(Exception es)
								{
									System.out.println(e);
									//ps.setString(25,"");
									masterObj.setC29("");
									q5="";
								}
								}
								else
								{
									//ps.setString(25,"");
								masterObj.setC29("");
								q5="";
								}
								
							}
							
						
						}
						catch(Exception es)
						{
							es.printStackTrace();
						}
					}
					
					
					
					String[] s7=s1[z3].split(":");
					String[] s71=s7[1].split("\t+");
					s71[0]=s71[0].replace("-","");
					System.out.println(s71[0]);
					//ps.setString(38,s71[0]);
					masterObj.setC38(s71[0]);
					
					for(int i=z3;i<s1.length;i++)
					{
						System.out.println(s1[i]);
						try{
						s7=s1[i].split("\\s{2,}");
						s8[i]=s7[0];
						s9[i]=s7[1];
						System.out.println(s9[i]);
						s0[i]=s7[2];
						System.out.println(s0[i]);
						}
						catch(Exception es)
						{
							
						}
					}
					
					int zz=34;
					for(int i=z3+1;i<s9.length&&zz<38;i++)
					{
						
						if(s9[i]!=null)
						{
							try{
						//	ps4.setString(1,s9[i]);
							System.out.println(s0[i]);
							String u=s0[i].replaceAll("[^\\x00-\\x7F]","");
							String u1=u.replaceAll(",","");
							double u2=Double.valueOf(u1);
							if(zz==34){
								masterObj.setC34(u2+"");
								q6=u2+"";
							}else if(zz==35){
								masterObj.setC35(u2+"");
								q7=u2+"";
							}
							else if(zz==36){
								masterObj.setC36(u2+"");
								q8=u2+"";
							}
							else if(zz==37){
								masterObj.setC37(u2+"");
								q9=u2+"";
							}
							//ps.setDouble(zz,u2);
							zz=zz+1;
							System.out.println(u2);
					
							}
							catch(Exception es)
							{

								if(zz==34){
									masterObj.setC34(0+"");
									q6=0+"";
								}else if(zz==35){
									masterObj.setC35(0+"");
									q7=0+"";
								}
								else if(zz==36){
									masterObj.setC36(0+"");
									q8=0+"";
								}
								else if(zz==37){
									masterObj.setC37(0+"");
									q9=0+"";
								}
								zz=zz+1;
							}
						}
						

						
					}
					
					masterObj.setC39("");
					
					
					long millis=System.currentTimeMillis();  
			        java.sql.Date date=new java.sql.Date(millis);  
					
					masterObj.setSys_date(date);
					
					String f2="",f12="";
					int xx=0,flag=0,u=0;
					System.out.println("PPPPPPPPPPPPPPPPPPPPPPPPPPPP");
					for(int i=z2+2;i<z3-1;i++)
					{
						System.out.println("xx="+xx);
						String n=s1[i];
						String[] n1=n.split("\\t+");
						try{
						if(s1[i]!=""&&n1[0].matches("[A-Za-z0-9]+")){
							System.out.println(s1[i]);
						String[] s6=s1[i].split("\\t+");
						try{
							if(s6[0].matches("[A-Za-z0-9]+"))
							{
								System.out.println("KKKKKK");
								if(flag==0)
								{
									u=i;
									flag=1;
								}
							f2=s6[0];
							System.out.println(f2+"f222222222222222");
						
							OodoData masterObj1= new OodoData();
							
							if(i>u)
							{
								
								masterObj1.setC1(e1[0]);
								masterObj1.setC2(e1[1]);
								masterObj1.setC3(h1);
								masterObj1.setC4(h2);
								masterObj1.setC5(h3);
								masterObj1.setC6(h4);
								masterObj1.setC7(h5);
								masterObj1.setC8(h6);						
								masterObj1.setC9(h7);							
								masterObj1.setC10(h8);							
								masterObj1.setC11(h9);
								masterObj1.setC12(h10);						
								masterObj1.setC13(h11);							
								masterObj1.setC14(h12);							
								masterObj1.setC15(h13);
								masterObj1.setC16(h14);
								masterObj1.setC17(h15);
								masterObj1.setC18(h16);
								masterObj1.setC19(h17);
								masterObj1.setC20(h18);
								masterObj1.setC21(hh1);
								masterObj1.setC22(hh);
								masterObj1.setC23(ss);
								masterObj1.setC24(ss1);
								masterObj1.setC25(q1);
								masterObj1.setC26(q2);
								masterObj1.setC27(q3);
								masterObj1.setC28(q4);
								masterObj1.setC29(q5);
								//masterObj1.setC30(f2);
								//masterObj1.setC31(f12);
								//masterObj1.setC32(f+"");
								//masterObj1.setC33(r+"");
								masterObj1.setC34(q6);
								masterObj1.setC35(q7);
								masterObj1.setC36(q8);
								masterObj1.setC37(q9);
								masterObj1.setC38(s71[0]);
								masterObj1.setC39("");
								
							}
							f2=s6[0];
							//if(f2.contains("RH"))
							//	break;
							//ps.setString(28,f2);
							if(i==u)
							{
								masterObj.setC30(f2);
								System.out.println(f2+"JJJJ");
							}
							if(i>u)
								masterObj1.setC30(f2);
							System.out.println(s6[0]);
							f12=s6[1];
							//ps.setString(29,f12);
							if(i==u)
								masterObj.setC31(f12);
							if(i>u)
								masterObj1.setC31(f12);
							System.out.println(s6[1]);
							if(s6[1].equals(null))
								System.out.println("");
							String ww=s6[2].replaceAll("[^\\x00-\\x7F]","");
							String w=ww.replaceAll(",","");
							double f=Double.valueOf(w);
							
							//ps.setDouble(30,f);
							if(i==u)
								masterObj.setC32(f+"");
							if(i>u)
								masterObj1.setC32(f+"");
							try{
							int r=Integer.valueOf(s6[3]);
							
							//ps.setInt(31,r);
							if(i==u)
								masterObj.setC33(r+"");
							if(i>u)
								masterObj1.setC33(r+"");
							}
							catch(Exception es)
							{
								//ps.setInt(31,0);
								if(i==u)
								masterObj.setC33(0+"");
								if(i>u)
								masterObj.setC33(0+"");
							}
							String ww1=s6[4].replaceAll("[^\\x00-\\x7F]","");
							String w1=ww1.replaceAll(",","");
							double f1=Double.valueOf(w1);
							System.out.println("---------------"+masterObj1.toString());
							if(i>u)
							{
								masterObj1.setSys_date(date);
							userDocumentService.saveOodoData(masterObj1);
							}
							
						}
						}
						catch(Exception es)
						{
							es.printStackTrace();
							System.out.println(es);
						}
						}
						}
						catch(Exception es)
						{
							System.out.println(es+"LLLL");
							
						}
					}
					
					
					
					
					userDocumentService.saveOodoData(masterObj);
					
					
					
				}
				
				/*InputStream is = new ByteArrayInputStream(file.getBytes());
				FileOutputStream fos = new FileOutputStream(theDir+"/"+file.getOriginalFilename().replace(" ", "_"));
				int b = 0;
				while ((b = is.read()) != -1)
					fos.write(b); 
				is.close();
				fos.close();
				
				String path=destPath+"";
				saveDocument(file,path);*/
				
				
				
			}
			ModelAndView mv = new ModelAndView("/admin/managedocument" , model);
			mv.addObject("Msg","Your Documents has uploaded Sucessfully.");
			return mv;
			
			
			
		 
		/*}*/
		 } 
		    catch(Exception see){

		    	see.printStackTrace();
		    	ModelAndView mv = new ModelAndView("/admin/managedocument" , model);
				mv.addObject("Msg","Your Document has not uploaded due to some problem , Please try again.");
			    return mv;
		    }
		
		
	}
	
	
	/**
	 The method will execute for saving the first Document .
	 */
	private void saveDocument(MultipartFile file, String path) throws IOException{
		
		UserDocument document = new UserDocument();
		
		
		document.setName1(file.getOriginalFilename());
		document.setType1(file.getContentType());
		document.setPath1(path);
		userDocumentService.saveDocument(document);
	}
	
	/**
	 The method will execute for saving the Second Document .
	 */
	
    private void saveDocumentNew(MultipartFile file,MultipartFile file1, String path, String path1) throws IOException{
		
		UserDocument document = new UserDocument();
		
		
		//MultipartFile multipartFile = fileBucket.getFile();
		document.setName1(file.getOriginalFilename());
		document.setType1(file.getContentType());
		document.setPath1(path);
		document.setName2(file1.getOriginalFilename());
		document.setType2(file1.getContentType());
		document.setPath2(path1);
		userDocumentService.saveDocument(document);
	}
	


    /**
	 The method will execute for comparing the two documents and getting the keywords .
	 */
  
    private void comparingTwoFiles(String path, String path1) throws IOException{
	
	BufferedReader br = null;
	String sCurrentLine;

	BufferedReader br1 = null;
	String sCurrentLine1;
	
	List<String> sublistOfFile1=new ArrayList<String>();
	
	List<String> sublistOfFile2=new ArrayList<String>();
	
	try{
	br = new BufferedReader(new FileReader(path));
	int k=0;
	Read1 read1=new Read1();
	
	br1 = new BufferedReader(new FileReader(path1));
	int k1=0;
	Read2 read2=new Read2();
	
	
	Read31 read31=new Read31();
	
	
	
	
	while ((sCurrentLine = br.readLine()) != null) {
		k++;
		
		if(sCurrentLine.contains(":")){
			sCurrentLine=sCurrentLine.trim();
			String[] s=sCurrentLine.split(":");
			
			for(int j=0;j<s.length;j++)
			{
				
				/*hashmap1.put(s[0], s[1]);
				
				Set set = hashmap1.entrySet();
			      Iterator iterator = set.iterator();
			      while(iterator.hasNext()) {
			         Map.Entry mentry = (Map.Entry)iterator.next();
			         listOfFile1.add((String) mentry.getKey());
			         
			         System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
			         System.out.println(mentry.getValue());
			      }*/
				
				if(s.length>2){
					String[] s1=s[1].split("\\s{3,}");
					System.out.println(s1.length+"llllllllllllllllllll");
					for(int i=0; i<s1.length; i++){
						sublistOfFile1.add(s1[i]);
					}
				}
				String[] s2=s[0].split("\\s{3,}");
				for(int i=0; i<s2.length; i++){
					sublistOfFile1.add(s2[i]);
				}
				
				
			}
			
			System.out.println(sCurrentLine);
			read1.setData(sCurrentLine);
			read1.setLine(k);
			userDocumentService.saveFileOne(read1);
			
		}
	}
	
	//System.out.println(sublistOfFile1.size()+"sizezzzzzzzzzzzzzzz");
	
	while ((sCurrentLine1 = br1.readLine()) != null) {
		k1++;
		
		
		
		if(sCurrentLine1.contains(":")){
			sCurrentLine1=sCurrentLine1.trim();
			String[] s=sCurrentLine1.split(":");
			
			for(int j=0;j<s.length;j++)
			{
				
				if(s.length>2){
					String[] s1=s[1].split("\\s{3,}");
					System.out.println(s1.length+"llllllllllllllllllll");
					for(int i=0; i<s1.length; i++){
						sublistOfFile2.add(s1[i]);
					}
				}
				
				
				String[] s2=s[0].split("\\s{3,}");
				for(int i=0; i<s2.length; i++){
					sublistOfFile2.add(s2[i]);
				}
				
				
			}
			
			read2.setData(sCurrentLine1);
			read2.setLine(k1);
			userDocumentService.saveFileTwo(read2);
			System.out.println(sCurrentLine1);
			
			
			}
		
		
		
		
	}
	
	System.out.println(sublistOfFile2.size()+"sizezzzzzzzzzzzzzzz");
	
	
	String subkeywords;
	
for(int i=0; i<sublistOfFile1.size(); i++){
	subkeywords="";
		for(int j=0; j<sublistOfFile2.size(); j++){
			
			
			
			if(sublistOfFile1.get(i)!= null && sublistOfFile2.get(j)!=null){
				if(sublistOfFile1.get(i).equals(sublistOfFile2.get(j))){
					
					subkeywords=sublistOfFile1.get(i);
					System.out.println(subkeywords+"ssssssssssssssssssssssssss");
					read31.setData(subkeywords);
					userDocumentService.saveMatchingSubKeywords(read31);
					
				}
				
				
			}
		}
		
	}
	
	
	System.out.println(" records got added");
	}catch (Exception see){
		see.printStackTrace();
	}
}

    /**
	 The method will execute for  getting  key and value pairs .
	 */


    private void gettingKeyValue(String path) throws IOException{
    	
    	
    	
    	
    }
    @RequestMapping("/exportExeclForToday")
    public void exportSysDateData() throws ClassNotFoundException, SQLException{
    	
    	
    	long millis=System.currentTimeMillis();  
        java.sql.Date date=new java.sql.Date(millis);
    	List<OodoData> rs= new ArrayList<OodoData>();
        
        
    	try {
    		  
    	   /* Class.forName("com.mysql.jdbc.Driver");
    	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/keywordsfinder", "root", "root123");
    	    Statement st = con.createStatement();
    	    ResultSet rs = st.executeQuery("Select * from oodo_data where sys_date="+date.toString());*/
    	   
    		rs=userDocumentService.fetchDataForExcel(date);
    		HSSFWorkbook workbook = new HSSFWorkbook();
    	    HSSFSheet sheet = workbook.createSheet("lawix10");
    	    HSSFRow rowhead = sheet.createRow((short) 0);
    	    rowhead.createCell((short) 0).setCellValue("Purchase order no.umber");
    	    rowhead.createCell((short) 1).setCellValue("Purchase Order Date(Dated)");
    	    rowhead.createCell((short) 2).setCellValue("Reseller/Dealer Information(name / Company Name) ");
    	    rowhead.createCell((short) 3).setCellValue("Reseller/Dealer Information(Street1)");
    	    rowhead.createCell((short) 4).setCellValue("Reseller/Dealer (Street2)");
    	    rowhead.createCell((short) 5).setCellValue("Reseller/Dealer (City)");
    	    rowhead.createCell((short) 6).setCellValue("Reseller/Dealer (State)");
    	    rowhead.createCell((short) 7).setCellValue("Reseller/Dealer (Contact Person)");
    	    rowhead.createCell((short) 8).setCellValue("Reseller/Dealer (Email_id)");
    	    rowhead.createCell((short) 9).setCellValue("Reseller/Dealer (Phone/Mobile number)");
    	    rowhead.createCell((short) 10).setCellValue("Reseller/Dealer (Pin Code)");
    	    rowhead.createCell((short) 11).setCellValue("Reseller/Dealer (Country)");
    	    rowhead.createCell((short) 12).setCellValue("End-customer(Name /company Name)");
    	    rowhead.createCell((short) 13).setCellValue("End-customer(Street1)");
    	    rowhead.createCell((short) 14).setCellValue("End-customer(Street2)");
    	    rowhead.createCell((short) 15).setCellValue("End-customer(City)");
    	    rowhead.createCell((short) 16).setCellValue("End-customer(State)");
    	    rowhead.createCell((short) 17).setCellValue("End-customer(Country)");
    	    rowhead.createCell((short) 18).setCellValue("End-customer(Contact person)");
    	    rowhead.createCell((short) 19).setCellValue("End-customer(Contact person email id)");
    	    rowhead.createCell((short) 20).setCellValue("End-customer(Phone/Mobile)");
    	    rowhead.createCell((short) 21).setCellValue("End-customer(Zip)");
    	    rowhead.createCell((short) 22).setCellValue("Acct# or Red Hat Network Login (if known):");
    	    rowhead.createCell((short) 23).setCellValue("Contract Number");
    	    rowhead.createCell((short) 24).setCellValue("Reseller P.O.");
    	    rowhead.createCell((short) 25).setCellValue("Contract Start Date");
    	    rowhead.createCell((short) 26).setCellValue("Reseller Account");
    	    rowhead.createCell((short) 27).setCellValue("SKU#");
    	    rowhead.createCell((short) 28).setCellValue("Product Description");
    	    rowhead.createCell((short) 29).setCellValue("Unit Price");
    	    rowhead.createCell((short) 30).setCellValue("Quantity");
    	    rowhead.createCell((short) 31).setCellValue("Cst");
    	    rowhead.createCell((short) 32).setCellValue("Sevice tax");
    	    rowhead.createCell((short) 33).setCellValue("Sbc Tax");
    	    rowhead.createCell((short) 34).setCellValue("Kkc Tax");
    	    rowhead.createCell((short) 35).setCellValue("Vendor");
    	    rowhead.createCell((short) 36).setCellValue("Billing & Shipping Address");
    	    rowhead.createCell((short) 37).setCellValue("Payment Terms");
    	    rowhead.createCell((short) 38).setCellValue("SFDC ID");
    	    //rowhead.createCell((short) 38).setCellValue("asdf");
    	    //rowhead.createCell((short) 39).setCellValue("asdf");
    	    int i = 1;
    	   /* while (rs.next()){
    	        HSSFRow row = sheet.createRow((short) i);
    	        row.createCell((short) 0).setCellValue(Long.toString(rs.getLong("id")));
    	        row.createCell((short) 1).setCellValue(rs.getString("c1"));
    	        row.createCell((short) 2).setCellValue(rs.getString("c2"));
    	        i++;
    	    }*/
    	    
    	    for(int p=0;p<rs.size();p++){
    	    	 HSSFRow row = sheet.createRow((short) i);
    	    	 row.createCell((short) 0).setCellValue(rs.get(p).getC1());
    	    	 row.createCell((short) 1).setCellValue(rs.get(p).getC2());
    	    	 row.createCell((short) 2).setCellValue(rs.get(p).getC4());
    	    	 row.createCell((short) 3).setCellValue(rs.get(p).getC6());
    	    	 row.createCell((short) 4).setCellValue(rs.get(p).getC8());
    	    	 row.createCell((short) 5).setCellValue(rs.get(p).getC9());
    	    	 row.createCell((short) 6).setCellValue(rs.get(p).getC13());
    	    	 row.createCell((short) 7).setCellValue(rs.get(p).getC17());
    	    	 row.createCell((short) 8).setCellValue(rs.get(p).getC20());
    	    	 row.createCell((short) 9).setCellValue(rs.get(p).getC21());
    	    	 row.createCell((short) 10).setCellValue(rs.get(p).getC14());
    	    	 row.createCell((short) 11).setCellValue(rs.get(p).getC12());
    	    	 row.createCell((short) 12).setCellValue(rs.get(p).getC3());
    	    	 row.createCell((short) 13).setCellValue(rs.get(p).getC5());
    	    	 row.createCell((short) 14).setCellValue(rs.get(p).getC7());
    	    	 row.createCell((short) 15).setCellValue(rs.get(p).getC11());
    	    	 row.createCell((short) 16).setCellValue(rs.get(p).getC15());
    	    	 row.createCell((short) 17).setCellValue(rs.get(p).getC10());
    	    	 row.createCell((short) 18).setCellValue(rs.get(p).getC18());
    	    	 row.createCell((short) 19).setCellValue(rs.get(p).getC19());
    	    	 row.createCell((short) 20).setCellValue(rs.get(p).getC22());
    	    	 row.createCell((short) 21).setCellValue(rs.get(p).getC16());
    	    	 row.createCell((short) 22).setCellValue(rs.get(p).getC27());
    	    	 row.createCell((short) 23).setCellValue(rs.get(p).getC28());
    	    	 row.createCell((short) 24).setCellValue(rs.get(p).getC29());
    	    	 row.createCell((short) 25).setCellValue(rs.get(p).getC25());
    	    	 row.createCell((short) 26).setCellValue(rs.get(p).getC26());
    	    	 row.createCell((short) 27).setCellValue(rs.get(p).getC30());
    	    	 row.createCell((short) 28).setCellValue(rs.get(p).getC31());
    	    	 row.createCell((short) 29).setCellValue(rs.get(p).getC32());
    	    	 row.createCell((short) 30).setCellValue(rs.get(p).getC33());
    	    	 row.createCell((short) 31).setCellValue(rs.get(p).getC34());
    	    	 row.createCell((short) 32).setCellValue(rs.get(p).getC35());
    	    	 row.createCell((short) 33).setCellValue(rs.get(p).getC36());
    	    	 row.createCell((short) 34).setCellValue(rs.get(p).getC37());
    	    	 row.createCell((short) 35).setCellValue(rs.get(p).getC23());
    	    	 row.createCell((short) 36).setCellValue(rs.get(p).getC24());
    	    	 row.createCell((short) 37).setCellValue(rs.get(p).getC38());
    	    	 row.createCell((short) 38).setCellValue(rs.get(p).getC39());
    	    	 
    	    	 i++;
    	    }
    	   
    	    
    	   
    	    
    	    String yemi = "D:\\docs\\Xls\\"+date.toString()+".xls";
    	    FileOutputStream fileOut = new FileOutputStream(yemi);
    	    workbook.write(fileOut);
    	    fileOut.close();
    	    } catch (FileNotFoundException e1) {
    	        e1.printStackTrace();
    	    } catch (IOException e1) {
    	        e1.printStackTrace();
    	    }
    	try {
			Desktop.getDesktop().open(new File("D:\\docs\\Xls\\"+date.toString()+".xls"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
}



 class Mymethod {
	 String s2="",s5="",s21="",s51="";
		String s11="";
	public  void  method1(String s1i)
	{
		
		s2="";s5="";s21="";s51="";
		System.out.println(s1i);
		
		if(s1i.contains(":"))
		{
			String[] s3=s1i.split(":");
			if(s3[0].contains("&"))
			{
				StringBuilder sb= new StringBuilder();
				String mainString=s1i;
				String[] fst=mainString.split(":");
				String [] secnd= fst[1].split("\t");
				//System.out.println(secnd[1]+" "+secnd[2]+"  Part 1");
				try{
				s2=secnd[1];
				}
				catch(Exception e)
				{
					s2="";
				}
				try{
				s5=secnd[2];
				}
				catch(Exception e)
				{
					s5="";
				}
				for(int i1=3;i1<secnd.length;i1++){
					sb.append(secnd[i1]);
					
					sb.append(" ");
				}
				System.out.println(sb.toString()+" Part 2");
				String[] xx=sb.toString().split("\\s{2}+");
				try{
				System.out.println(xx[0]+"hj");
				s21=xx[0];
				System.out.println(xx[1]);
				s51=xx[1];
				}
				catch(Exception e)
				{}
		      }

			else
			{
				System.out.println(s3[1]);
				String[] s4=s3[1].trim().split("\\s{2,}");
				s2=s4[0];
				s11=s3[0];
				try{
					System.out.println(s2);
					System.out.println("hi");
					System.out.println(s4[1]);
					s5=s4[1];	
					}
				catch(Exception e)
				{}
			}
		}
		else{
			
			/*if(i==z2-2)
			{
		System.out.println(s1[i]);
		String[] sd=s1[i].split("");
		System.out.println(sd[0]);
		System.out.println(sd[1]);
		String[] sd1=s1[i].split("Reseller account");
		try{
		System.out.println(sd1[0]+"hh");
		sd1[0]=sd1[0].replace("Contract Start Date","");
		System.out.println(sd1[0]+"hh");
		System.out.println(sd1[1]+"hh");
		sd1[1]=sd1[1].replace("#","");
		System.out.println(sd1[1]+"hh");
		}
		catch(Exception e)
		{}
			}
		}*/
			
	}
		}
}


