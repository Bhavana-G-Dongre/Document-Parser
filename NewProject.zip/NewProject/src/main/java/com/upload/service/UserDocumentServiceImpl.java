package com.upload.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.upload.dao.UserDocumentDao;
import com.upload.model.OodoData;
import com.upload.model.Read1;
import com.upload.model.Read2;
import com.upload.model.Read31;
import com.upload.model.Read5;
import com.upload.model.UserDocument;

@Service("userDocumentService")
@Transactional
public class UserDocumentServiceImpl implements UserDocumentService{

	@Autowired
	UserDocumentDao dao;

	
	
	public void saveDocument(UserDocument document){
		dao.save(document);
	}



	public void saveFileOne(Read1 read1) {
		dao.saveFileOne(read1);
	}

	public void saveFileTwo(Read2 read2) {
		dao.saveFileTwo(read2);
	}



	public void saveMatchingKeywords(Read5 read5) {
		dao.saveMatchingKeywords(read5);
	}



	public void saveMatchingSubKeywords(Read31 read31) {
		dao.saveMatchingSubKeywords(read31);		
	}



	public void saveOodoData(OodoData obj) {
		dao.saveOodoData(obj);
	}



	


	public List<OodoData> fetchDataForExcel(Date date) {
		return dao.fetchDataForExcel(date);
	}
	
}
