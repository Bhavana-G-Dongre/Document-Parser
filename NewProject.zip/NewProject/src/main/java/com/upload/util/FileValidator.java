package com.upload.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.upload.model.FileBucket;



@Component
public class FileValidator implements Validator {
	
	HttpServletRequest request;
	HttpServletResponse response;
		
	public boolean supports(Class<?> clazz) {
		return FileBucket.class.isAssignableFrom(clazz);
	}

	public void validate(Object obj, Errors errors) {
		FileBucket file = (FileBucket) obj;
			
		if(file.getFile()!=null ){
			if(file.getFile().getSize() > 1000000000){
				System.out.println("false");
				errors.rejectValue("file", "large.file");
			}
			if (file.getFile().getSize() == 0 ) {
				System.out.println("false");
				errors.rejectValue("file", "missing.file");
				/*errors.rejectValue("docType", "missing.doctype");
				errors.rejectValue("loanRefNo", "missing.loanRefNo");
				errors.rejectValue("applicant", "missing.applicant");*/
				//response.setHeader("Refresh", "0; URL=" + request.getContextPath());
			} 
			
			
		}
		
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
}

