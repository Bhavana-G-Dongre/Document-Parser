package com.upload.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.upload.model.OodoData;
import com.upload.model.Read1;
import com.upload.model.Read2;
import com.upload.model.Read31;
import com.upload.model.Read5;
import com.upload.model.UserDocument;

@Repository("userDocumentDao")
public class UserDocumentDaoImpl  implements UserDocumentDao{

	
	@Autowired
	private SessionFactory sessionFactory;
	

	public void save(UserDocument document) {
		sessionFactory.getCurrentSession().save(document);
	}


	public void saveFileOne(Read1 read1) {
		sessionFactory.getCurrentSession().save(read1);
	}

	
	public void saveFileTwo(Read2 read2) {
		sessionFactory.getCurrentSession().save(read2);
	}

	

	public void saveMatchingKeywords(Read5 read5) {
		sessionFactory.getCurrentSession().save(read5);		
	}


	public void saveMatchingSubKeywords(Read31 read31) {
		sessionFactory.getCurrentSession().save(read31);	
	}


	public void saveOodoData(OodoData obj) {
		
		sessionFactory.openSession().save(obj);
	}


	

	public List<OodoData> fetchDataForExcel(Date date) {
		return sessionFactory.openSession().createQuery("from OodoData where sys_date='"+date+"'").list();
	}

	
	

}
