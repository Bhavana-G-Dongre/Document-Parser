package com.upload.dao;

import java.util.Date;
import java.util.List;

import com.upload.model.OodoData;
import com.upload.model.Read1;
import com.upload.model.Read2;
import com.upload.model.Read31;
import com.upload.model.Read5;
import com.upload.model.UserDocument;

public interface UserDocumentDao {

	
	void save(UserDocument document);
	
	void saveFileOne(Read1 read1);
	
	void saveFileTwo(Read2 read2);
	
	void saveMatchingKeywords(Read5 read5);
	
	void saveMatchingSubKeywords(Read31 read31);
	
	void saveOodoData(OodoData obj);
	
	public List<OodoData> fetchDataForExcel(Date date); 
	
	
}
